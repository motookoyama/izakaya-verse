import { useState } from 'react';
import { ArtNouveauCharacterCard } from './components/art-nouveau-character-card';
import { ArtNouveauMultiplayerChat } from './components/art-nouveau-multiplayer-chat';
import { Button } from './components/ui/button';
import { Card, CardContent } from './components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Badge } from './components/ui/badge';
import { Users, Leaf, Crown, Trophy, Sparkles, MessageSquare } from 'lucide-react';
import { ImageWithFallback } from './components/figma/ImageWithFallback';

interface Character {
  id: string;
  name: string;
  type: string;
  rarity: "Common" | "Rare" | "Epic" | "Legendary";
  power: number;
  health: number;
  abilities: string[];
  image: string;
  owned: boolean;
}

interface Player {
  id: string;
  name: string;
  avatar: string;
  character: string;
  isOnline: boolean;
}

const characters: Character[] = [
  {
    id: '1',
    name: 'Iris of the Garden',
    type: 'Botanical Muse',
    rarity: 'Legendary',
    power: 95,
    health: 80,
    abilities: ['Floral Symphony', 'Nature\'s Grace', 'Ethereal Bloom'],
    image: 'https://images.unsplash.com/photo-1682589183655-2b9062af9a77?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnQlMjBub3V2ZWF1JTIwZmxvcmFsJTIwcGF0dGVybnxlbnwxfHx8fDE3NTg1Mzk3NTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    owned: true
  },
  {
    id: '2',
    name: 'Gilded Artisan',
    type: 'Master Craftsman',
    rarity: 'Epic',
    power: 88,
    health: 65,
    abilities: ['Golden Touch', 'Ornamental Shield', 'Artistic Vision'],
    image: 'https://images.unsplash.com/photo-1743877427459-ed950b323498?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnQlMjBub3V2ZWF1JTIwb3JuYW1lbnQlMjBnb2xkfGVufDF8fHx8MTc1ODUzOTc2MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    owned: true
  },
  {
    id: '3',
    name: 'Rose Whisperer',
    type: 'Garden Keeper',
    rarity: 'Rare',
    power: 70,
    health: 120,
    abilities: ['Thorn Guard', 'Petal Dance', 'Garden\'s Blessing'],
    image: 'https://images.unsplash.com/photo-1667858133290-2384d3f19b53?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwdmludGFnZSUyMGZsb3dlcnN8ZW58MXx8fHwxNzU4NTM5NzY0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    owned: false
  },
  {
    id: '4',
    name: 'Botanical Scholar',
    type: 'Illuminator',
    rarity: 'Epic',
    power: 82,
    health: 75,
    abilities: ['Manuscript Magic', 'Herbal Wisdom', 'Illuminated Text'],
    image: 'https://images.unsplash.com/photo-1574087274792-b82d8d1e7094?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwYm90YW5pY2FsJTIwaWxsdXN0cmF0aW9ufGVufDF8fHx8MTc1ODQzMzgzMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    owned: true
  }
];

export default function App() {
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(characters.find(c => c.owned) || null);
  const [activeTab, setActiveTab] = useState('collection');
  const [currentPlayer] = useState<Player>({
    id: '1',
    name: 'Player1',
    avatar: '🌿',
    character: selectedCharacter?.name || 'No Character',
    isOnline: true
  });

  const handleCharacterSelect = (id: string) => {
    const character = characters.find(c => c.id === id);
    if (character && character.owned) {
      setSelectedCharacter(character);
    }
  };

  const handleStartAdventure = () => {
    setActiveTab('adventure');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-100 via-amber-50 to-yellow-100 relative">
      {/* Background Image */}
      <div className="absolute inset-0 opacity-15">
        <ImageWithFallback 
          src="https://images.unsplash.com/photo-1682589183655-2b9062af9a77?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnQlMjBub3V2ZWF1JTIwZmxvcmFsJTIwcGF0dGVybnxlbnwxfHx8fDE3NTg1Mzk3NTR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Art Nouveau floral pattern"
          className="w-full h-full object-cover sepia-[0.2]"
        />
      </div>

      {/* Decorative border */}
      <div className="absolute inset-4 border-4 border-yellow-600/20 rounded-lg pointer-events-none">
        <div className="absolute top-0 left-0 w-8 h-8 border-l-4 border-t-4 border-yellow-600/40 rounded-tl-lg"></div>
        <div className="absolute top-0 right-0 w-8 h-8 border-r-4 border-t-4 border-yellow-600/40 rounded-tr-lg"></div>
        <div className="absolute bottom-0 left-0 w-8 h-8 border-l-4 border-b-4 border-yellow-600/40 rounded-bl-lg"></div>
        <div className="absolute bottom-0 right-0 w-8 h-8 border-r-4 border-b-4 border-yellow-600/40 rounded-br-lg"></div>
      </div>

      {/* Header */}
      <div className="relative z-10 p-6">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-500 to-amber-600 rounded-full flex items-center justify-center border-4 border-yellow-700 shadow-lg">
              <Leaf className="w-8 h-8 text-yellow-100" />
            </div>
            <div className="text-center">
              <h1 className="text-5xl text-transparent bg-gradient-to-r from-amber-700 via-yellow-600 to-amber-700 bg-clip-text drop-shadow-lg font-serif">
                IZAKAYA verse
              </h1>
              <div className="flex items-center justify-center gap-2 mt-1">
                <div className="w-6 h-0.5 bg-gradient-to-r from-transparent to-yellow-600"></div>
                <Crown className="w-5 h-5 text-yellow-600" />
                <div className="w-6 h-0.5 bg-gradient-to-l from-transparent to-yellow-600"></div>
              </div>
            </div>
            <div className="w-16 h-16 bg-gradient-to-br from-amber-500 to-yellow-600 rounded-full flex items-center justify-center border-4 border-amber-700 shadow-lg">
              <Sparkles className="w-8 h-8 text-amber-100" />
            </div>
          </div>
          <p className="text-amber-800 text-xl drop-shadow font-serif italic">
            ⚜ Exquisite Character Collection & Art Nouveau Adventure ⚜
          </p>
        </div>

        {/* Stats */}
        <div className="flex justify-center gap-6 mb-8">
          <Card className="bg-white/70 backdrop-blur-sm border-2 border-amber-400/50 shadow-lg">
            <CardContent className="p-4 text-center">
              <Users className="w-6 h-6 text-amber-600 mx-auto mb-2" />
              <p className="text-amber-800 text-sm font-serif">Distinguished Patrons</p>
              <p className="text-amber-700 font-serif">2,847</p>
            </CardContent>
          </Card>
          <Card className="bg-white/70 backdrop-blur-sm border-2 border-yellow-400/50 shadow-lg">
            <CardContent className="p-4 text-center">
              <Trophy className="w-6 h-6 text-yellow-600 mx-auto mb-2" />
              <p className="text-yellow-800 text-sm font-serif">Artistic Soirées</p>
              <p className="text-yellow-700 font-serif">15,632</p>
            </CardContent>
          </Card>
          <Card className="bg-white/70 backdrop-blur-sm border-2 border-stone-400/50 shadow-lg">
            <CardContent className="p-4 text-center">
              <Crown className="w-6 h-6 text-stone-600 mx-auto mb-2" />
              <p className="text-stone-800 text-sm font-serif">Artistic Spirits</p>
              <p className="text-stone-700 font-serif">156</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 px-6 pb-6">
        <div className="max-w-7xl mx-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-white/80 backdrop-blur-sm border-2 border-yellow-500 shadow-lg">
              <TabsTrigger 
                value="collection" 
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-amber-500 data-[state=active]:to-yellow-500 data-[state=active]:text-yellow-50 font-serif"
              >
                <Crown className="w-4 h-4 mr-2" />
                ⚜ Artistic Collection
              </TabsTrigger>
              <TabsTrigger 
                value="adventure"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-yellow-500 data-[state=active]:to-amber-500 data-[state=active]:text-amber-50 font-serif"
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                🌿 Enchanted Salon
              </TabsTrigger>
            </TabsList>

            <TabsContent value="collection" className="mt-6">
              <div className="grid lg:grid-cols-2 gap-8">
                {/* Character Selection */}
                <div className="space-y-6">
                  <div className="text-center">
                    <h2 className="text-3xl text-amber-900 mb-2 font-serif">Your Artistic Gallery ⚜</h2>
                    <p className="text-amber-700 font-serif italic">Curate and cherish exquisite artistic spirits for your adventures</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    {characters.map((character) => (
                      <ArtNouveauCharacterCard
                        key={character.id}
                        {...character}
                        onSelect={handleCharacterSelect}
                      />
                    ))}
                  </div>
                </div>

                {/* Selected Character & Adventure Start */}
                <div className="space-y-6">
                  {selectedCharacter ? (
                    <div className="space-y-4">
                      <Card className="bg-gradient-to-br from-white/80 to-amber-50/80 border-2 border-yellow-500/50 backdrop-blur-sm shadow-lg">
                        <CardContent className="p-6 text-center">
                          <h3 className="text-xl text-amber-900 mb-4 font-serif">Chosen Artistic Spirit ⚜</h3>
                          <div className="space-y-3">
                            <h4 className="text-lg text-amber-900 font-serif">{selectedCharacter.name}</h4>
                            <div className="flex justify-center gap-4">
                              <Badge className="bg-amber-100 text-amber-800 border-amber-400 font-serif">
                                <Crown className="w-3 h-3 mr-1" />
                                {selectedCharacter.power}
                              </Badge>
                              <Badge className="bg-emerald-100 text-emerald-800 border-emerald-400 font-serif">
                                <Leaf className="w-3 h-3 mr-1" />
                                {selectedCharacter.health}
                              </Badge>
                            </div>
                            <div className="flex flex-wrap gap-1 justify-center">
                              {selectedCharacter.abilities.map((ability, index) => (
                                <Badge 
                                  key={index}
                                  variant="outline" 
                                  className="text-xs bg-gradient-to-r from-stone-50 to-amber-50 text-stone-700 border-stone-400 font-serif"
                                >
                                  {ability}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Button 
                        onClick={handleStartAdventure}
                        className="w-full bg-gradient-to-r from-yellow-600 to-amber-600 hover:from-yellow-700 hover:to-amber-700 text-yellow-50 text-lg py-6 shadow-lg hover:shadow-amber-200/50 border-2 border-yellow-700 font-serif"
                      >
                        <Sparkles className="w-5 h-5 mr-2" />
                        Enter the Enchanted Salon ⚜
                      </Button>
                    </div>
                  ) : (
                    <Card className="bg-white/50 border-2 border-amber-300 backdrop-blur-sm">
                      <CardContent className="p-6 text-center">
                        <div className="text-amber-600">
                          <Crown className="w-12 h-12 mx-auto mb-4 opacity-50" />
                          <p className="font-serif italic">Choose an artistic spirit from your gallery to begin your cultural journey ⚜</p>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                  
                  <div className="space-y-4 text-center">
                    <h3 className="text-xl text-amber-800 font-serif">Salon Features 🌿</h3>
                    <div className="space-y-2 text-amber-700">
                      <p className="flex items-center justify-center gap-2 font-serif">
                        <Users className="w-4 h-4 text-amber-600" />
                        Cultivated soirées with AI Curator 🌹
                      </p>
                      <p className="flex items-center justify-center gap-2 font-serif">
                        <Crown className="w-4 h-4 text-yellow-600" />
                        Collect & bond with artistic spirits ⚜
                      </p>
                      <p className="flex items-center justify-center gap-2 font-serif">
                        <Sparkles className="w-4 h-4 text-stone-600" />
                        AI-guided Art Nouveau narratives 🍃
                      </p>
                      <p className="flex items-center justify-center gap-2 font-serif">
                        <Trophy className="w-4 h-4 text-amber-600" />
                        Elegant exhibitions & cultural rankings 🏛️
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="adventure" className="mt-6">
              <Card className="bg-white/90 backdrop-blur-sm border-2 border-yellow-600 shadow-2xl">
                <div className="h-[700px]">
                  <ArtNouveauMultiplayerChat 
                    roomId="Conservatory-001" 
                    currentPlayer={{
                      ...currentPlayer,
                      character: selectedCharacter?.name || 'No Character'
                    }}
                  />
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
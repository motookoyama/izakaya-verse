"use client"

import React, { useEffect, useMemo, useState } from "react"
import { Settings, Globe, Sparkles, Bot, TicketIcon, LibraryIcon, HomeIcon, Upload, ChevronRight } from "lucide-react"
import { useTranslation } from "react-i18next"

// ==========================================================
// IZAKAYA verse – Phase 1 (Next.js App Router conversion)
// - Hash-based router (no History API to avoid sandbox SecurityError)
// - i18n (ja/en)
// - Admin mock (points / forced card / TTS toggle / counters)
// - Play: tabs + chat (mock) + V2 card upload (PNG/JSON/.sAtd)
//   * PNG: avatar only (metadata parse is deferred per spec)
// ==========================================================

// ----------------------------------------------------------
// i18n
// ----------------------------------------------------------
const I18N = {
  ja: {
    heroTag: "Manga-inspired AI experience",
    ctaTry: "試してみる",
    summaryTitle: "IZAKAYA verseとは",
    summaryBody:
      "マンガ由来のキャラクター体験を中心に据えたAIプレイグラウンド。V2カードを読み込み、気軽に対話＆遊びを拡張できます。",
    news: "お知らせ",
    ticketsLead: "QRチケット案内へ",
    navHome: "Home",
    navPlay: "Play",
    navLibrary: "Library",
    navTickets: "Tickets",
    admin: "管理者モード",
    points: "ポイント",
    forceCard: "カード強制切替",
    ttsTrial: "TTS試験",
    sent: "送信",
    received: "応答",
    ttsClicks: "TTS クリック",
    uploadV2: "V2カード読み込み (PNG/JSON/.sAtd)",
    messagePlaceholder: "メッセージを入力…",
    send: "送信",
    libraryIntro: "初期3キャラのギャラリー。将来は投稿/交換のハブに拡張予定（UIはプレースホルダ）。",
    adminOnly: "(管理者のみ) アップロード済みカード一覧（仮）",
    disabledSoon: "(将来対応)",
    ticketsTitle: "ポイント制ガイド",
    ticketsText:
      "フェーズ1では説明とUIのみ。実課金・照合はダミーAPIに接続し、将来差し替えます。登録時にお試し200ptが付与されます。",
    price1000: "1000円 = 1000pt",
    price5000: "5000円 = 6000pt（ボーナス）",
    dynQR: "ダイナミックQR前提の説明",
    pdfDraft: "PDFチケット（ドラフト）をダウンロード",
    faqLead: "FAQ（将来: PayPal/Stripe 予告）",
    redeemTitle: "ポイント引き換え（ダイナミックQRトークン）",
    tokenIs: "受け取ったトークン",
    fallbackCard: "（V2カードを検出できませんでした。first_mes を置換できません）",
    firstMes: "first_mes",
    quickAccess: "クイックアクセス",
  },
  en: {
    heroTag: "Manga-inspired AI experience",
    ctaTry: "Try it now",
    summaryTitle: "What is IZAKAYA verse?",
    summaryBody:
      "A manga-flavored AI playground centered around V2 cards. Load a card, chat, and expand your experience.",
    news: "News",
    ticketsLead: "Go to QR Tickets",
    navHome: "Home",
    navPlay: "Play",
    navLibrary: "Library",
    navTickets: "Tickets",
    admin: "Admin",
    points: "Points",
    forceCard: "Force Card",
    ttsTrial: "TTS Trial",
    sent: "Sent",
    received: "Received",
    ttsClicks: "TTS Clicks",
    uploadV2: "Load V2 Card (PNG/JSON/.sAtd)",
    messagePlaceholder: "Type a message…",
    send: "Send",
    libraryIntro: "Gallery for the initial three characters. Future: user submissions & exchanges (placeholder UI).",
    adminOnly: "(Admin only) Uploaded card list (mock)",
    disabledSoon: "(Coming soon)",
    ticketsTitle: "Points Guide",
    ticketsText:
      "Phase 1 is UI-only. Payments & verification connect to a dummy API, swappable later. 200 trial points upon registration.",
    price1000: "¥1,000 = 1,000pt",
    price5000: "¥5,000 = 6,000pt (bonus)",
    dynQR: "Dynamic QR primer",
    pdfDraft: "Download PDF Ticket (draft)",
    faqLead: "FAQ (Future: PayPal/Stripe)",
    redeemTitle: "Redeem (Dynamic QR token)",
    tokenIs: "Received token",
    fallbackCard: "(Could not detect a V2 card. Could not replace first_mes.)",
    firstMes: "first_mes",
    quickAccess: "Quick Access",
  },
}
function useI18n() {
  const [lang, setLang] = useState("ja")
  const dict = I18N[lang]
  const t = (k) => dict?.[k] ?? k
  return { lang, setLang, t }
}

// ----------------------------------------------------------
// Utilities & Providers (MVP)
// ----------------------------------------------------------
const cx = (...xs) => xs.filter(Boolean).join(" ")
const hasJapanese = (s) => /[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]/.test(String(s || ""))
function autoLocalizeForUI(text, lang) {
  const s = String(text || "")
  if (lang === "ja" && !hasJapanese(s)) return `【日本語要約(モック)】\n${s}`
  return s
}
function usePoints(initial = 200) {
  const [points, setPoints] = useState(initial)
  const add = (n) => setPoints((p) => Math.max(0, p + n))
  const spend = (n) => setPoints((p) => Math.max(0, p - n))
  return { points, add, spend }
}
const ttsProvider = {
  enabled: false,
  setEnabled(v) {
    this.enabled = v
  },
  async speak(_) {
    await new Promise((r) => setTimeout(r, 120))
  },
}

// ----------------------------------------------------------
// Simple Client-Side Router (no hash manipulation to avoid selector issues)
// ----------------------------------------------------------
function useRouter() {
  const [path, setPath] = useState("/")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  const push = (to) => {
    let targetPath = to
    if (!targetPath.startsWith("/")) {
      targetPath = "/" + targetPath
    }
    setPath(targetPath)
  }

  return { path: mounted ? path : "/", push }
}

const RouterContext = React.createContext(null)
function useRouterContext() {
  const ctx = React.useContext(RouterContext)
  if (!ctx) throw new Error("useRouterContext must be used within provider")
  return ctx
}

function NavLink({ to, children, className, onClick }) {
  const { push, path } = useRouterContext()

  let targetPath = to
  if (!targetPath.startsWith("/")) {
    targetPath = "/" + targetPath
  }

  const isActive = path === targetPath

  return (
    <button
      className={className}
      onClick={(e) => {
        e.preventDefault()
        onClick?.(e)
        push(to)
      }}
    >
      {children}
    </button>
  )
}

// ----------------------------------------------------------
// V2 Card parsing (Enhanced): JSON/.sAtd => full metadata, PNG => embedded JSON + avatar
// ----------------------------------------------------------
function safeJsonParse(text) {
  try {
    return JSON.parse(text)
  } catch {
    return null
  }
}

async function extractPNGChunks(file) {
  try {
    const buffer = await file.arrayBuffer()
    const view = new DataView(buffer)

    // PNG signature check
    if (view.getUint32(0) !== 0x89504e47 || view.getUint32(4) !== 0x0d0a1a0a) {
      return null
    }

    let offset = 8
    const chunks = []

    while (offset < buffer.byteLength - 8) {
      const length = view.getUint32(offset)
      const type = new TextDecoder().decode(buffer.slice(offset + 4, offset + 8))
      const data = buffer.slice(offset + 8, offset + 8 + length)

      chunks.push({ type, data, length })
      offset += 8 + length + 4 // length + type + data + crc
    }

    // Extract JSON from text chunks
    for (const chunk of chunks) {
      if (chunk.type === "tEXt") {
        const text = new TextDecoder().decode(chunk.data)
        const nullIndex = text.indexOf("\0")
        if (nullIndex > 0) {
          const jsonText = text.substring(nullIndex + 1)
          const parsed = safeJsonParse(jsonText)
          if (parsed) return parsed
        }
      } else if (chunk.type === "iTXt") {
        const text = new TextDecoder().decode(chunk.data)
        const parts = text.split("\0")
        if (parts.length >= 5) {
          const compressionFlag = parts[1].charCodeAt(0)
          const jsonText = parts[4]
          if (compressionFlag === 0) {
            const parsed = safeJsonParse(jsonText)
            if (parsed) return parsed
          }
        }
      } else if (chunk.type === "zTXt" && "DecompressionStream" in window) {
        try {
          const text = new TextDecoder().decode(chunk.data)
          const nullIndex = text.indexOf("\0")
          if (nullIndex > 0) {
            const compressed = chunk.data.slice(nullIndex + 2) // skip keyword + null + method
            const stream = new DecompressionStream("deflate")
            const writer = stream.writable.getWriter()
            const reader = stream.readable.getReader()

            writer.write(compressed)
            writer.close()

            const result = await reader.read()
            const decompressed = new TextDecoder().decode(result.value)
            const parsed = safeJsonParse(decompressed)
            if (parsed) return parsed
          }
        } catch (e) {
          console.log("[v0] zTXt decompression failed:", e)
        }
      }
    }

    return null
  } catch (e) {
    console.log("[v0] PNG chunk extraction failed:", e)
    return null
  }
}

function normalizeV2Like(obj) {
  if (!obj || typeof obj !== "object") return null

  // Try different nesting patterns
  let data = null
  if (obj.data?.first_mes) data = obj.data
  else if (obj.spec?.first_mes) data = obj.spec
  else if (obj.card?.first_mes) data = obj.card
  else if (obj.first_mes) data = obj

  if (!data) return null

  return {
    name: data.name || data.character || data.title || "Unknown",
    first_mes: data.first_mes || "",
    description: data.description || data.personality || "",
    personality: data.personality || "",
    scenario: data.scenario || "",
    mes_example: data.mes_example || data.example_dialogue || "",
    system_prompt: data.system_prompt || "",
    behavior: data.behavior || data.description || data.system_prompt || "",
    links: Array.isArray(data.links) ? data.links : [],
    // Additional SillyTavern fields
    creator: data.creator || "",
    character_version: data.character_version || "",
    tags: Array.isArray(data.tags) ? data.tags : [],
    creator_notes: data.creator_notes || "",
    post_history_instructions: data.post_history_instructions || "",
    alternate_greetings: Array.isArray(data.alternate_greetings) ? data.alternate_greetings : [],
  }
}

async function parseV2CardFromFile(file) {
  const name = (file.name || "").toLowerCase()

  if (name.endsWith(".json") || name.endsWith(".satd")) {
    const text = await file.text()
    const norm = normalizeV2Like(safeJsonParse(text))
    if (norm) return { ...norm, __avatarUrl: null }
    return null
  }

  if (name.endsWith(".png")) {
    try {
      const url = URL.createObjectURL(file)
      const embeddedData = await extractPNGChunks(file)

      if (embeddedData) {
        const norm = normalizeV2Like(embeddedData)
        if (norm) {
          return { ...norm, __avatarUrl: url }
        }
      }

      // Fallback: PNG with avatar only
      return {
        name: "PNG Character",
        first_mes: "こんにちは！PNGファイルからキャラクターデータを読み込みました。",
        description: "PNG画像から読み込まれたキャラクター",
        __avatarUrl: url,
      }
    } catch (e) {
      console.log("[v0] PNG parsing failed:", e)
      return null
    }
  }

  return null
}

function buildCharacterPrompt(card) {
  if (!card) return ""

  let prompt = ""

  // Character identity
  if (card.name) {
    prompt += `Character Name: ${card.name}\n`
  }

  // Core personality and description
  if (card.description) {
    prompt += `Description: ${card.description}\n`
  }

  if (card.personality) {
    prompt += `Personality: ${card.personality}\n`
  }

  // Scenario context
  if (card.scenario) {
    prompt += `Scenario: ${card.scenario}\n`
  }

  // Example dialogue for style reference
  if (card.mes_example) {
    prompt += `Example Dialogue:\n${card.mes_example}\n`
  }

  // System instructions
  if (card.system_prompt) {
    prompt += `System Instructions: ${card.system_prompt}\n`
  }

  if (card.behavior) {
    prompt += `Behavior Guidelines: ${card.behavior}\n`
  }

  // Additional context
  if (card.post_history_instructions) {
    prompt += `Post-History Instructions: ${card.post_history_instructions}\n`
  }

  return prompt.trim()
}

// ----------------------------------------------------------
// App Shell
// ----------------------------------------------------------
export default function App() {
  const router = useRouter()
  const i18n = useI18n()
  const pointsApi = usePoints(200)
  const [admin, setAdmin] = useState(false)
  const [forcedCardKey, setForcedCardKey] = useState("orb")
  const [counters, setCounters] = useState({ sent: 0, received: 0, tts: 0 })
  const [ttsOn, setTtsOn] = useState(false)
  const [customCards, setCustomCards] = useState([])

  useEffect(() => {
    ttsProvider.setEnabled(ttsOn)
  }, [ttsOn])

  const ctx = useMemo(
    () => ({
      ...router,
      ...i18n,
      admin,
      setAdmin,
      pointsApi,
      forcedCardKey,
      setForcedCardKey,
      counters,
      setCounters,
      ttsOn,
      setTtsOn,
      customCards,
      setCustomCards,
    }),
    [router, i18n, admin, pointsApi, forcedCardKey, counters, ttsOn, customCards],
  )

  return (
    <RouterContext.Provider value={ctx}>
      <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white text-zinc-800">
        <TopNav />
        <main className="mx-auto max-w-6xl px-4 pb-24 pt-8">
          <Routes />
        </main>
        <Footer />
      </div>
    </RouterContext.Provider>
  )
}

// ----------------------------------------------------------
// Top Navigation with Symbolic Logo (ASCII filename)
// ----------------------------------------------------------
function TopNav() {
  const { path, lang, setLang, admin, setAdmin, t } = useRouterContext()
  const linkCls = (p) =>
    cx("px-3 py-2 rounded-xl text-sm", path === p ? "bg-red-100 text-red-600" : "hover:bg-pink-100 text-zinc-700")
  return (
    <header className="sticky top-0 z-40 backdrop-blur supports-[backdrop-filter]:bg-white/70 border-b border-pink-100">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="relative flex h-9 w-9 items-center justify-center rounded-2xl bg-gradient-to-br from-pink-200 to-red-300 text-white shadow">
            <img
              src="symbolic_logo.png"
              alt="logo"
              className="h-5 w-5"
              onError={(e) => {
                e.currentTarget.style.display = "none"
              }}
            />
            <Sparkles className="pointer-events-none absolute h-5 w-5" />
          </div>
          <div className="font-semibold text-red-700">IZAKAYA verse</div>
        </div>
        <nav className="hidden gap-1 md:flex">
          <NavLink to="/" className={linkCls("/")}>
            <span className="inline-flex items-center gap-2">
              <HomeIcon className="h-4 w-4" />
              {t("navHome")}
            </span>
          </NavLink>
          <NavLink to="/play" className={linkCls("/play")}>
            <span className="inline-flex items-center gap-2">
              <Bot className="h-4 w-4" />
              {t("navPlay")}
            </span>
          </NavLink>
          <NavLink to="/library" className={linkCls("/library")}>
            <span className="inline-flex items-center gap-2">
              <LibraryIcon className="h-4 w-4" />
              {t("navLibrary")}
            </span>
          </NavLink>
          <NavLink to="/tickets" className={linkCls("/tickets")}>
            <span className="inline-flex items-center gap-2">
              <TicketIcon className="h-4 w-4" />
              {t("navTickets")}
            </span>
          </NavLink>
        </nav>
        <div className="flex items-center gap-2">
          <button
            className={cx(
              "hidden md:inline-flex items-center gap-2 rounded-xl border px-3 py-2 text-sm shadow-sm transition",
              admin ? "border-red-300 bg-red-50 text-red-700" : "border-zinc-200 bg-white hover:bg-pink-50",
            )}
            onClick={() => setAdmin(!admin)}
            title={t("admin")}
          >
            <Settings className="h-4 w-4" /> {t("admin")}
          </button>
          <button
            className="inline-flex items-center gap-2 rounded-xl border border-zinc-200 bg-white px-3 py-2 text-sm shadow-sm hover:bg-pink-50"
            onClick={() => setLang(lang === "ja" ? "en" : "ja")}
            title="i18n"
          >
            <Globe className="h-4 w-4" /> {lang.toUpperCase()}
          </button>
        </div>
      </div>
    </header>
  )
}

function Footer() {
  return (
    <footer className="border-t border-pink-100 py-6 text-center text-xs text-zinc-500">
      <div className="mx-auto max-w-6xl px-4">© {new Date().getFullYear()} IZAKAYA verse – Phase 1 (UI only)</div>
    </footer>
  )
}

// ----------------------------------------------------------
// Routes (simple state-based routing)
// ----------------------------------------------------------
function Routes() {
  const { path } = useRouterContext()
  const p = path || "/"
  if (p.startsWith("/redeem/")) return <RedeemPage />
  switch (p) {
    case "/":
      return <HomePage />
    case "/play":
      return <PlayPage />
    case "/library":
      return <LibraryPage />
    case "/tickets":
      return <TicketsPage />
    default:
      return <NotFound />
  }
}

function HomePage() {
  const { t } = useRouterContext()
  return (
    <div className="space-y-10">
      <section className="rounded-3xl bg-gradient-to-br from-pink-200/60 to-red-100/70 p-8 shadow-md">
        <div className="flex flex-col items-start gap-6 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight text-red-700 flex items-center gap-3">
              <Sparkles className="h-6 w-6" /> IZAKAYA verse
            </h1>
            <p className="mt-2 text-zinc-700">{t("heroTag")}</p>
            <div className="mt-4 h-32 w-full rounded-xl bg-gray-200 flex items-center justify-center text-xs text-gray-500">
              banner_placeholder.png
            </div>
          </div>
          <div className="flex items-center gap-3">
            <NavLink
              to="/play"
              className="inline-flex items-center gap-2 rounded-2xl bg-red-500 px-5 py-3 text-white shadow-lg transition hover:bg-red-600"
            >
              <Bot className="h-5 w-5" /> {t("ctaTry")} <ChevronRight className="h-4 w-4" />
            </NavLink>
          </div>
        </div>
      </section>

      <section className="flex items-center justify-between rounded-2xl bg-pink-50 p-4 shadow">
        <span className="text-sm font-medium text-zinc-700">{t("quickAccess")}</span>
        <div className="flex gap-3">
          <NavLink to="/play" className="rounded-xl bg-red-100 px-4 py-2 text-red-700">
            Play
          </NavLink>
          <NavLink to="/tickets" className="rounded-xl bg-red-100 px-4 py-2 text-red-700">
            Tickets
          </NavLink>
        </div>
      </section>
    </div>
  )
}

const PRESET_CARDS = {
  orb: {
    key: "orb",
    name: "Dr. Orb",
    first_mes: "私はDr. Orb。AI考古学の酒場へようこそ。今日の一杯はアルゴリズム・ハイボールだ。",
    behavior: "論理→比喩→ユーモアの順に返答。難解さは避ける。リンク提示は2件まで。",
    __avatarUrl: "/characters/dr-orb.png",
    links: [
      { title: "Lab notes", url: "#" },
      { title: "Field log", url: "#" },
    ],
  },
  ekubo: {
    key: "ekubo",
    name: "Ekubo",
    first_mes: "えくぼは恋の落とし穴。さ、軽口交わして肩の力を抜こう。",
    behavior: "軽妙・短文・間合い重視。時々関西弁。",
    __avatarUrl: "/characters/ekubo.png",
    links: [
      { title: "Playbook", url: "#" },
      { title: "Clips", url: "#" },
    ],
  },
  madi: {
    key: "madi",
    name: "Miss Madi",
    first_mes: "ミス・マディよ。可愛げは武器。ルールは守るけど、抜け道も知ってるの。",
    behavior: "礼儀正しく、しかし核心は突く。提案は3つ以内。",
    __avatarUrl: "/characters/miss-madi.png",
    links: [
      { title: "Madi Notes", url: "#" },
      { title: "Etiquette", url: "#" },
    ],
  },
}

function PlayPage() {
  const { forcedCardKey, setForcedCardKey, admin, t, counters, setCounters, ttsOn, customCards, setCustomCards } =
    useRouterContext()
  const [activeCharacters, setActiveCharacters] = useState([forcedCardKey])
  const [currentSpeaker, setCurrentSpeaker] = useState(forcedCardKey)
  const [firstMesOverride, setFirstMesOverride] = useState("")
  const [isDragging, setIsDragging] = useState(false)
  const [characterPrompts, setCharacterPrompts] = useState({})
  const [messages, setMessages] = useState([])
  const [inputText, setInputText] = useState("")

  const baseCards = PRESET_CARDS
  const allCards = useMemo(() => {
    const cards = { ...baseCards }
    customCards.forEach((card, index) => {
      cards[`custom_${index}`] = {
        key: `custom_${index}`,
        name: card.name || "Custom",
        first_mes: card.first_mes || I18N.ja.fallbackCard,
        behavior: card.behavior || "（カスタムカード）",
        links: card.links || [],
        __avatarUrl: card.__avatarUrl || null,
        ...card,
      }
    })
    return cards
  }, [customCards])

  const activeCards = activeCharacters.map((key) => allCards[key]).filter(Boolean)
  const currentCard = allCards[currentSpeaker] || allCards.orb

  useEffect(() => {
    if (!activeCharacters.includes(forcedCardKey)) {
      setActiveCharacters([forcedCardKey])
      setCurrentSpeaker(forcedCardKey)
    }
  }, [forcedCardKey])

  useEffect(() => {
    const prompts = {}
    activeCards.forEach((card) => {
      prompts[card.key] = buildCharacterPrompt(card)
    })
    setCharacterPrompts(prompts)
    console.log("[v0] Character prompts built:", prompts)
  }, [activeCharacters, customCards]) // Fixed dependency array to use stable state variables instead of derived activeCards array

  const addCharacter = (key) => {
    if (activeCharacters.length >= 3) {
      alert("最大3人までのキャラクターを同時に使用できます")
      return
    }
    if (!activeCharacters.includes(key)) {
      setActiveCharacters((prev) => [...prev, key])
    }
  }

  const removeCharacter = (key) => {
    if (activeCharacters.length <= 1) return
    setActiveCharacters((prev) => prev.filter((k) => k !== key))
    if (currentSpeaker === key) {
      setCurrentSpeaker(activeCharacters.find((k) => k !== key))
    }
  }

  async function handleFiles(files) {
    const f = files?.[0]
    if (!f) return

    console.log("[v0] Processing file:", f.name)
    const data = await parseV2CardFromFile(f)
    console.log("[v0] Parsed V2 card data:", data)

    if (data) {
      const normalized = {
        name: data.name || "Custom",
        first_mes: data.first_mes || "こんにちは！",
        description: data.description || "",
        personality: data.personality || "",
        scenario: data.scenario || "",
        mes_example: data.mes_example || "",
        system_prompt: data.system_prompt || "",
        behavior: data.behavior || data.description || "",
        links: data.links || [],
        creator: data.creator || "",
        tags: data.tags || [],
        alternate_greetings: data.alternate_greetings || [],
        __avatarUrl: data.__avatarUrl || null,
      }

      setCustomCards((prev) => [...prev, normalized])
      const newKey = `custom_${customCards.length}`
      addCharacter(newKey)
      setCurrentSpeaker(newKey)
      setFirstMesOverride(normalized.first_mes)

      console.log("[v0] Custom card added:", normalized)
    } else {
      console.log("[v0] Failed to parse V2 card")
    }
  }

  const sendMessage = async () => {
    if (!inputText.trim()) return

    const userMsg = { role: "user", content: inputText, timestamp: Date.now() }
    setMessages((prev) => [...prev, userMsg])
    setCounters((prev) => ({ ...prev, sent: prev.sent + 1 }))
    setInputText("")

    setTimeout(() => {
      const aiResponse = {
        role: "assistant",
        content: autoLocalizeForUI(`${currentCard.name}: ${inputText}への応答（モック）`, "ja"),
        timestamp: Date.now(),
        character: currentCard.key,
        characterName: currentCard.name,
        characterAvatar: currentCard.__avatarUrl,
      }
      setMessages((prev) => [...prev, aiResponse])
      setCounters((prev) => ({ ...prev, received: prev.received + 1 }))

      if (ttsOn) {
        ttsProvider.speak(aiResponse.content)
        setCounters((prev) => ({ ...prev, tts: prev.tts + 1 }))
      }
    }, 800)
  }

  return (
    <div className="grid gap-6 md:grid-cols-3">
      <div className="space-y-4 md:col-span-1">
        <div className="rounded-2xl border border-pink-100 bg-white p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-zinc-700 mb-3">デフォルトキャラクター</h3>
          <div className="grid grid-cols-3 gap-2">
            {Object.values(baseCards).map((card) => (
              <button
                key={card.key}
                onClick={() => addCharacter(card.key)}
                className="flex flex-col items-center gap-2 p-2 rounded-xl border border-pink-100 hover:border-red-200 hover:bg-red-50 transition"
              >
                <img
                  src={card.__avatarUrl || "/placeholder.svg"}
                  alt={card.name}
                  className="w-8 h-8 rounded-full object-cover"
                />
                <span className="text-xs text-zinc-600">{card.name}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-red-100 bg-red-50 p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-red-700 mb-3">
            アクティブキャラクター ({activeCharacters.length}/3)
          </h3>
          <div className="space-y-2">
            {activeCards.map((card) => (
              <div
                key={card.key}
                className={cx(
                  "flex items-center gap-3 p-2 rounded-xl border transition cursor-pointer",
                  currentSpeaker === card.key ? "border-red-300 bg-red-100" : "border-red-200 bg-white hover:bg-red-50",
                )}
                onClick={() => setCurrentSpeaker(card.key)}
              >
                <img
                  src={card.__avatarUrl || "/placeholder.svg"}
                  alt="avatar"
                  className="w-8 h-8 rounded-full object-cover"
                />
                <div className="flex-1">
                  <div className="text-sm font-medium text-zinc-800">{card.name}</div>
                  <div className="text-xs text-zinc-500 truncate">{card.behavior}</div>
                </div>
                {activeCharacters.length > 1 && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation()
                      removeCharacter(card.key)
                    }}
                    className="text-red-400 hover:text-red-600 text-xs"
                  >
                    ×
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-pink-100 bg-white p-3 shadow-sm">
          <div className="flex items-center gap-3 mb-2">
            <img
              src={currentCard.__avatarUrl || "/placeholder.svg"}
              alt="avatar"
              className="h-10 w-10 rounded-full object-cover"
            />
            <div>
              <div className="font-medium text-zinc-800">{currentCard.name}</div>
              <div className="text-xs text-zinc-500">現在のスピーカー</div>
            </div>
          </div>
          <div className="rounded-xl bg-pink-50 p-3 text-sm text-zinc-700">
            <div className="font-medium">{t("firstMes")}:</div>
            <div className="mt-1 whitespace-pre-wrap">{firstMesOverride || currentCard.first_mes}</div>
            <div className="mt-2 text-xs text-zinc-500">behavior: {currentCard.behavior}</div>
            {currentCard.personality && (
              <div className="mt-1 text-xs text-zinc-500">personality: {currentCard.personality}</div>
            )}
            {currentCard.scenario && <div className="mt-1 text-xs text-zinc-500">scenario: {currentCard.scenario}</div>}
          </div>
        </div>

        <div
          className={cx(
            "rounded-2xl border bg-white p-4 shadow-sm transition",
            isDragging ? "border-red-300 ring-2 ring-red-200" : "border-pink-100",
          )}
          onDragOver={(e) => {
            e.preventDefault()
            setIsDragging(true)
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={(e) => {
            e.preventDefault()
            setIsDragging(false)
            handleFiles(e.dataTransfer.files)
          }}
        >
          <div className="text-sm font-semibold flex items-center gap-2">
            <Upload className="h-4 w-4" /> {t("uploadV2")}
          </div>
          <p className="mt-1 text-xs text-zinc-500">PNG（400x600）/JSON/.sAtd — SillyTavern互換（PNG埋め込み）</p>
        </div>

        {admin && Object.keys(characterPrompts).length > 0 && (
          <div className="rounded-2xl border border-orange-200 bg-orange-50 p-3 shadow-sm">
            <div className="text-sm font-semibold text-orange-700 mb-2">キャラクタープロンプト（管理者のみ）</div>
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {Object.entries(characterPrompts).map(([key, prompt]) => (
                <div key={key} className="text-xs">
                  <div className="font-medium text-orange-600">{allCards[key]?.name}:</div>
                  <div className="text-orange-600 whitespace-pre-wrap">{prompt}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="space-y-4 md:col-span-2">
        <div className="rounded-2xl border border-pink-100 bg-white shadow-sm">
          <div className="border-b border-pink-100 p-4">
            <h2 className="text-lg font-semibold text-zinc-800">マルチキャラクターチャット</h2>
            <p className="text-sm text-zinc-500">現在のスピーカー: {currentCard.name} | 応答をモック生成中</p>
          </div>

          <div className="h-96 overflow-y-auto p-4 space-y-3">
            {messages.length === 0 && (
              <div className="text-center text-zinc-400 py-8">
                <Bot className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p>メッセージを送信してチャットを開始</p>
              </div>
            )}

            {messages.map((msg, i) => (
              <div key={i} className={cx("flex gap-3", msg.role === "user" ? "justify-end" : "justify-start")}>
                {msg.role === "assistant" && msg.characterAvatar && (
                  <img
                    src={msg.characterAvatar || "/placeholder.svg"}
                    alt={msg.characterName}
                    className="w-8 h-8 rounded-full object-cover mt-1"
                  />
                )}
                <div
                  className={cx(
                    "max-w-xs rounded-2xl px-4 py-2 text-sm",
                    msg.role === "user" ? "bg-red-500 text-white" : "bg-pink-50 text-zinc-700",
                  )}
                >
                  {msg.role === "assistant" && msg.characterName && (
                    <div className="text-xs font-medium text-red-600 mb-1">{msg.characterName}</div>
                  )}
                  <div className="whitespace-pre-wrap">{msg.content}</div>
                  <div className="text-xs opacity-70 mt-1">{new Date(msg.timestamp).toLocaleTimeString()}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="border-t border-pink-100 p-4">
            <div className="flex gap-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendMessage()}
                placeholder={`${currentCard.name}に${t("messagePlaceholder")}`}
                className="flex-1 rounded-xl border border-pink-200 px-4 py-2 text-sm focus:border-red-300 focus:outline-none focus:ring-2 focus:ring-red-100"
              />
              <button
                onClick={sendMessage}
                disabled={!inputText.trim()}
                className="rounded-xl bg-red-500 px-4 py-2 text-sm text-white hover:bg-red-600 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {t("send")}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function RedeemPage() {
  // RedeemPage implementation
  return <div>RedeemPage</div>
}

function LibraryPage() {
  const { t, admin } = useRouterContext()
  const [viewSize, setViewSize] = useState("large") // large, medium, small
  const [sortBy, setSortBy] = useState("name") // name, tags, description

  const libraryCards = [
    {
      name: "Miss Madi",
      image: "/characters/miss-madi.png",
      description: "礼儀正しく、しかし核心は突く。提案は3つ以内。",
      tags: ["アニメ", "学生", "ツンデレ"],
    },
    {
      name: "Ekubo",
      image: "/characters/ekubo.png",
      description: "軽妙・短文・間合い重視。時々関西弁。",
      tags: ["小悪魔", "コメディ", "関西弁"],
    },
    {
      name: "華惣カワリ",
      image: "/characters/kawari.png",
      description: "優しく穏やかな性格のキャラクター。",
      tags: ["優しい", "日常", "癒し系"],
    },
    {
      name: "Dr. Orb",
      image: "/characters/dr-orb.png",
      description: "論理→比喩→ユーモアの順に返答。難解さは避ける。",
      tags: ["博士", "論理的", "ユーモア"],
    },
  ]

  const sortedCards = [...libraryCards].sort((a, b) => {
    switch (sortBy) {
      case "name":
        return a.name.localeCompare(b.name)
      case "tags":
        return a.tags[0]?.localeCompare(b.tags[0] || "") || 0
      case "description":
        return a.description.localeCompare(b.description)
      default:
        return 0
    }
  })

  const getGridClasses = () => {
    switch (viewSize) {
      case "small":
        return "grid gap-3 grid-cols-2 md:grid-cols-4 lg:grid-cols-6"
      case "medium":
        return "grid gap-4 grid-cols-2 md:grid-cols-3 lg:grid-cols-4"
      case "large":
      default:
        return "grid gap-4 md:grid-cols-2 lg:grid-cols-3"
    }
  }

  const getCardClasses = () => {
    const baseClasses = "rounded-2xl border border-pink-100 bg-white shadow-sm hover:shadow-md transition"
    switch (viewSize) {
      case "small":
        return `${baseClasses} p-2`
      case "medium":
        return `${baseClasses} p-3`
      case "large":
      default:
        return `${baseClasses} p-4`
    }
  }

  return (
    <div className="space-y-6">
      <div className="rounded-2xl bg-gradient-to-br from-pink-100 to-red-50 p-6 shadow-sm">
        <h1 className="text-2xl font-bold text-red-700 mb-2">ライブラリ</h1>
        <p className="text-zinc-600">{t("libraryIntro")}</p>
      </div>

      <div className="flex flex-wrap gap-4 items-center justify-between bg-white rounded-2xl p-4 shadow-sm">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-zinc-700">表示サイズ:</span>
          <div className="flex rounded-lg border border-zinc-200 overflow-hidden">
            {[
              { key: "large", label: "大", icon: "⬜" },
              { key: "medium", label: "中", icon: "◼" },
              { key: "small", label: "小", icon: "▪" },
            ].map(({ key, label, icon }) => (
              <button
                key={key}
                onClick={() => setViewSize(key)}
                className={`px-3 py-1 text-sm flex items-center gap-1 transition ${
                  viewSize === key ? "bg-red-500 text-white" : "bg-white text-zinc-600 hover:bg-zinc-50"
                }`}
              >
                <span>{icon}</span>
                <span>{label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-zinc-700">ソート:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="rounded-lg border border-zinc-200 px-3 py-1 text-sm bg-white"
          >
            <option value="name">名前順</option>
            <option value="tags">タグ順</option>
            <option value="description">説明順</option>
          </select>
        </div>
      </div>

      <div className={getGridClasses()}>
        {sortedCards.map((card, i) => (
          <div key={i} className={getCardClasses()}>
            <div className={`aspect-square rounded-xl overflow-hidden ${viewSize === "small" ? "mb-2" : "mb-3"}`}>
              <img
                src={card.image || "/placeholder.svg"}
                alt={card.name}
                className="w-full h-full object-cover filter contrast-110 saturate-110"
                style={{ imageRendering: "crisp-edges" }}
                onError={(e) => {
                  e.currentTarget.src = "/diverse-group-characters.png"
                }}
              />
            </div>
            <h3 className={`font-semibold text-zinc-800 ${viewSize === "small" ? "text-sm mb-1" : "mb-1"}`}>
              {card.name}
            </h3>
            {viewSize !== "small" && (
              <p className={`text-zinc-600 ${viewSize === "medium" ? "text-xs mb-2" : "text-sm mb-3"}`}>
                {card.description}
              </p>
            )}
            <div className={`flex flex-wrap gap-1 ${viewSize === "small" ? "mb-2" : "mb-3"}`}>
              {card.tags.slice(0, viewSize === "small" ? 1 : 3).map((tag, j) => (
                <span
                  key={j}
                  className={`px-2 py-1 bg-pink-100 text-pink-700 rounded-lg ${viewSize === "small" ? "text-xs" : "text-xs"}`}
                >
                  {tag}
                </span>
              ))}
            </div>
            <button
              className={`w-full rounded-xl bg-red-500 text-white hover:bg-red-600 transition ${viewSize === "small" ? "py-1 text-xs" : "py-2 text-sm"}`}
            >
              Playで使用
            </button>
          </div>
        ))}
      </div>

      {admin && (
        <div className="rounded-2xl border border-orange-200 bg-orange-50 p-4 shadow-sm">
          <h2 className="font-semibold text-orange-700 mb-2">{t("adminOnly")}</h2>
          <div className="text-sm text-orange-600">アップロード済みカードの管理機能（将来実装予定）</div>
        </div>
      )}
    </div>
  )
}

function TicketsPage() {
  const { t } = useTranslation()

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-4">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8 text-center">
          <h1 className="mb-4 text-4xl font-bold text-gray-800">
            <TicketIcon className="mr-2 inline-block h-8 w-8" />
            {t("ticketsTitle")}
          </h1>
          <p className="text-lg text-gray-600">{t("ticketsText")}</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {/* ポイント購入カード */}
          <div className="rounded-xl bg-white p-6 shadow-lg">
            <h2 className="mb-4 text-2xl font-semibold text-gray-800">ポイント購入</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between rounded-lg bg-blue-50 p-4">
                <span className="font-medium text-blue-800">{t("price1000")}</span>
                <button className="rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700">購入</button>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-green-50 p-4">
                <span className="font-medium text-green-800">{t("price5000")}</span>
                <button className="rounded-lg bg-green-600 px-4 py-2 text-white hover:bg-green-700">購入</button>
              </div>
            </div>
          </div>

          {/* 現在のポイント */}
          <div className="rounded-xl bg-white p-6 shadow-lg">
            <h2 className="mb-4 text-2xl font-semibold text-gray-800">現在のポイント</h2>
            <div className="text-center">
              <div className="mb-4 text-4xl font-bold text-purple-600">200pt</div>
              <p className="text-gray-600">お試しポイント付与済み</p>
            </div>
          </div>

          {/* Dynamic QR */}
          <div className="rounded-xl bg-white p-6 shadow-lg">
            <h2 className="mb-4 text-2xl font-semibold text-gray-800">{t("dynQR")}</h2>
            <div className="flex items-center justify-center rounded-lg bg-gray-100 p-8">
              <div className="h-32 w-32 rounded-lg bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center">
                <span className="text-white font-bold">QR</span>
              </div>
            </div>
            <p className="mt-4 text-center text-sm text-gray-600">動的QRコード（Phase 2で実装予定）</p>
          </div>

          {/* PDF チケット */}
          <div className="rounded-xl bg-white p-6 shadow-lg">
            <h2 className="mb-4 text-2xl font-semibold text-gray-800">チケット生成</h2>
            <button className="w-full rounded-lg bg-red-600 px-4 py-3 text-white hover:bg-red-700 flex items-center justify-center gap-2">
              <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                />
              </svg>
              {t("pdfDraft")}
            </button>
            <p className="mt-2 text-center text-sm text-gray-600">ドラフト版PDF（Phase 1機能）</p>
          </div>
        </div>

        {/* FAQ セクション */}
        <div className="mt-8 rounded-xl bg-white p-6 shadow-lg">
          <h2 className="mb-4 text-2xl font-semibold text-gray-800">{t("faqLead")}</h2>
          <div className="space-y-4">
            <div className="rounded-lg bg-gray-50 p-4">
              <h3 className="font-semibold text-gray-800">Q: 支払い方法は？</h3>
              <p className="text-gray-600">A: Phase 2でPayPal/Stripe統合予定です。現在はダミーAPI接続中。</p>
            </div>
            <div className="rounded-lg bg-gray-50 p-4">
              <h3 className="font-semibold text-gray-800">Q: ポイントの有効期限は？</h3>
              <p className="text-gray-600">A: Phase 1では制限なし。将来的に利用規約で定義予定。</p>
            </div>
            <div className="rounded-lg bg-gray-50 p-4">
              <h3 className="font-semibold text-gray-800">Q: 返金は可能？</h3>
              <p className="text-gray-600">A: 正式リリース後に返金ポリシーを策定予定です。</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function NotFound() {
  // NotFound implementation
  return <div>NotFound</div>
}

import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  QrCode,
  Download,
  Settings,
  Globe,
  Volume2,
  Sparkles,
  Bot,
  Ticket as TicketIcon,
  Library as LibraryIcon,
  Home as HomeIcon,
  Upload,
  ChevronRight,
  MessageSquare,
} from "lucide-react";

// ==========================================================
// IZAKAYA verse – Phase 1 (Single-file React SPA, MVP)
// - Hash-based router (no History API to avoid sandbox SecurityError)
// - i18n (ja/en)
// - Admin mock (points / forced card / TTS toggle / counters)
// - Play: tabs + chat (mock) + V2 card upload (PNG/JSON/.sAtd)
//   * PNG: avatar only (metadata parse is deferred per spec)
// ==========================================================

// ----------------------------------------------------------
// i18n
// ----------------------------------------------------------
const I18N = {
  ja: {
    heroTag: "Manga-inspired AI experience",
    ctaTry: "試してみる",
    summaryTitle: "IZAKAYA verseとは",
    summaryBody:
      "マンガ由来のキャラクター体験を中心に据えたAIプレイグラウンド。V2カードを読み込み、気軽に対話＆遊びを拡張できます。",
    news: "お知らせ",
    ticketsLead: "QRチケット案内へ",
    navHome: "Home",
    navPlay: "Play",
    navLibrary: "Library",
    navTickets: "Tickets",
    admin: "管理者モード",
    points: "ポイント",
    forceCard: "カード強制切替",
    ttsTrial: "TTS試験",
    sent: "送信",
    received: "応答",
    ttsClicks: "TTS クリック",
    uploadV2: "V2カード読み込み (PNG/JSON/.sAtd)",
    messagePlaceholder: "メッセージを入力…",
    send: "送信",
    libraryIntro:
      "初期3キャラのギャラリー。将来は投稿/交換のハブに拡張予定（UIはプレースホルダ）。",
    adminOnly: "（管理者のみ）アップロード済みカード一覧（仮）",
    disabledSoon: "（将来対応）",
    ticketsTitle: "ポイント制ガイド",
    ticketsText:
      "フェーズ1では説明とUIのみ。実課金・照合はダミーAPIに接続し、将来差し替えます。登録時にお試し200ptが付与されます。",
    price1000: "1000円 = 1000pt",
    price5000: "5000円 = 6000pt（ボーナス）",
    dynQR: "ダイナミックQR前提の説明",
    pdfDraft: "PDFチケット（ドラフト）をダウンロード",
    faqLead: "FAQ（将来: PayPal/Stripe 予告）",
    redeemTitle: "ポイント引き換え（ダイナミックQRトークン）",
    tokenIs: "受け取ったトークン",
    fallbackCard: "（V2カードを検出できませんでした。first_mes を置換できません）",
    firstMes: "first_mes",
    quickAccess: "クイックアクセス",
  },
  en: {
    heroTag: "Manga-inspired AI experience",
    ctaTry: "Try it now",
    summaryTitle: "What is IZAKAYA verse?",
    summaryBody:
      "A manga-flavored AI playground centered around V2 cards. Load a card, chat, and expand your experience.",
    news: "News",
    ticketsLead: "Go to QR Tickets",
    navHome: "Home",
    navPlay: "Play",
    navLibrary: "Library",
    navTickets: "Tickets",
    admin: "Admin",
    points: "Points",
    forceCard: "Force Card",
    ttsTrial: "TTS Trial",
    sent: "Sent",
    received: "Received",
    ttsClicks: "TTS Clicks",
    uploadV2: "Load V2 Card (PNG/JSON/.sAtd)",
    messagePlaceholder: "Type a message…",
    send: "Send",
    libraryIntro:
      "Gallery for the initial three characters. Future: user submissions & exchanges (placeholder UI).",
    adminOnly: "(Admin only) Uploaded card list (mock)",
    disabledSoon: "(Coming soon)",
    ticketsTitle: "Points Guide",
    ticketsText:
      "Phase 1 is UI-only. Payments & verification connect to a dummy API, swappable later. 200 trial points upon registration.",
    price1000: "¥1,000 = 1,000pt",
    price5000: "¥5,000 = 6,000pt (bonus)",
    dynQR: "Dynamic QR primer",
    pdfDraft: "Download PDF Ticket (draft)",
    faqLead: "FAQ (Future: PayPal/Stripe)",
    redeemTitle: "Redeem (Dynamic QR token)",
    tokenIs: "Received token",
    fallbackCard:
      "(Could not detect a V2 card. Could not replace first_mes.)",
    firstMes: "first_mes",
    quickAccess: "Quick Access",
  },
};
function useI18n(){
  const [lang, setLang] = useState("ja");
  const dict = I18N[lang];
  const t = (k)=> dict?.[k] ?? k;
  return { lang, setLang, t };
}

// ----------------------------------------------------------
// Utilities & Providers (MVP)
// ----------------------------------------------------------
const cx = (...xs) => xs.filter(Boolean).join(" ");
const hasJapanese = (s)=>(/[\\u3040-\\u30ff\\u3400-\\u4dbf\\u4e00-\\u9fff]/).test(String(s||""));
function autoLocalizeForUI(text, lang){
  const s=String(text||"");
  if(lang==='ja' && !hasJapanese(s)) return `【日本語要約(モック)】\\n${s}`;
  return s;
}
function usePoints(initial=200){
  const [points,setPoints]=useState(initial);
  const add=(n)=>setPoints((p)=>Math.max(0, p+n));
  const spend=(n)=>setPoints((p)=>Math.max(0, p-n));
  return { points, add, spend };
}
const ttsProvider={ enabled:false, setEnabled(v){ this.enabled=v; }, async speak(_){ await new Promise(r=>setTimeout(r,120)); } };

// ----------------------------------------------------------
// Hash Router (no pushState)
// ----------------------------------------------------------
function getHashPath(){ const raw=window.location.hash||"#/"; return raw.startsWith('#')? (raw.slice(1)||'/') : '/'; }
function useRouter(){
  const [path,setPath]=useState(getHashPath());
  useEffect(()=>{
    if(!window.location.hash) window.location.hash = "#/";
    const onChange=()=>setPath(getHashPath());
    window.addEventListener('hashchange', onChange);
    return ()=>window.removeEventListener('hashchange', onChange);
  },[]);
  const push=(to)=>{ const target=to.startsWith('/')?`#${to}`:`#/${to}`; if(window.location.hash!==target){ window.location.hash=target; setPath(getHashPath()); } };
  return { path, push };
}
const RouterContext = React.createContext(null);
function useRouterContext(){ const ctx=React.useContext(RouterContext); if(!ctx) throw new Error('useRouterContext must be used within provider'); return ctx; }
function NavLink({to,children,className,onClick}){ const {push}=useRouterContext(); const href=to.startsWith('/')?`#${to}`:`#/${to}`; return <a href={href} className={className} onClick={(e)=>{e.preventDefault(); onClick?.(e); push(to);}}>{children}</a>; }

// ----------------------------------------------------------
// V2 Card parsing (MVP): JSON/.sAtd => metadata, PNG => avatar only
// ----------------------------------------------------------
function safeJsonParse(text){ try{ return JSON.parse(text);}catch{ return null; } }
function normalizeV2Like(obj){ if(!obj||typeof obj!=='object') return null; if(obj.data?.first_mes) return obj.data; if(obj.spec?.first_mes) return obj.spec; if(obj.card?.first_mes) return obj.card; if(obj.first_mes) return obj; return null; }
async function parseV2CardFromFile(file){
  const name=(file.name||"").toLowerCase();
  if(name.endsWith('.json')||name.endsWith('.satd')){
    const text=await file.text();
    const norm=normalizeV2Like(safeJsonParse(text));
    if(norm) return { ...norm, __avatarUrl:null };
    return null;
  }
  if(name.endsWith('.png')){
    try{ const url=URL.createObjectURL(file); return { __avatarUrl:url }; }catch{ return null; }
  }
  return null;
}

// ----------------------------------------------------------
// App Shell
// ----------------------------------------------------------
export default function App(){
  const router=useRouter();
  const i18n=useI18n();
  const pointsApi=usePoints(200);
  const [admin,setAdmin]=useState(false);
  const [forcedCardKey,setForcedCardKey]=useState('orb');
  const [counters,setCounters]=useState({sent:0,received:0,tts:0});
  const [ttsOn,setTtsOn]=useState(false);
  useEffect(()=>{ ttsProvider.setEnabled(ttsOn); },[ttsOn]);
  const ctx=useMemo(()=>({ ...router, ...i18n, admin,setAdmin, pointsApi, forcedCardKey,setForcedCardKey, counters,setCounters, ttsOn,setTtsOn }),[router,i18n,admin,pointsApi,forcedCardKey,counters,ttsOn]);
  return (
    <RouterContext.Provider value={ctx}>
      <div className="min-h-screen bg-gradient-to-b from-pink-50 to-white text-zinc-800">
        <TopNav />
        <main className="mx-auto max-w-6xl px-4 pb-24 pt-8"><Routes /></main>
        <Footer />
      </div>
    </RouterContext.Provider>
  );
}

// ----------------------------------------------------------
// Top Navigation with Symbolic Logo (ASCII filename)
// ----------------------------------------------------------
function TopNav(){
  const { path, lang,setLang, admin,setAdmin, t } = useRouterContext();
  const linkCls=(p)=>cx("px-3 py-2 rounded-xl text-sm", path===p?"bg-red-100 text-red-600":"hover:bg-pink-100 text-zinc-700");
  return (
  <header className="sticky top-0 z-40 backdrop-blur supports-[backdrop-filter]:bg-white/70 border-b border-pink-100">
    <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
      <div className="flex items-center gap-3">
        <div className="relative flex h-9 w-9 items-center justify-center rounded-2xl bg-gradient-to-br from-pink-200 to-red-300 text-white shadow">
          <img src="symbolic_logo.png" alt="logo" className="h-5 w-5" onError={(e)=>{e.currentTarget.style.display='none';}}/>
          <Sparkles className="pointer-events-none absolute h-5 w-5"/>
        </div>
        <div className="font-semibold text-red-700">IZAKAYA verse</div>
      </div>
      <nav className="hidden gap-1 md:flex">
        <NavLink to="/" className={linkCls("/")}><span className="inline-flex items-center gap-2"><HomeIcon className="h-4 w-4" />{t("navHome")}</span></NavLink>
        <NavLink to="/play" className={linkCls("/play")}><span className="inline-flex items-center gap-2"><Bot className="h-4 w-4" />{t("navPlay")}</span></NavLink>
        <NavLink to="/library" className={linkCls("/library")}><span className="inline-flex items-center gap-2"><LibraryIcon className="h-4 w-4" />{t("navLibrary")}</span></NavLink>
        <NavLink to="/tickets" className={linkCls("/tickets")}><span className="inline-flex items-center gap-2"><TicketIcon className="h-4 w-4" />{t("navTickets")}</span></NavLink>
      </nav>
      <div className="flex items-center gap-2">
        <button className={cx("hidden md:inline-flex items-center gap-2 rounded-xl border px-3 py-2 text-sm shadow-sm transition", admin?"border-red-300 bg-red-50 text-red-700":"border-zinc-200 bg-white hover:bg-pink-50")} onClick={()=>setAdmin(!admin)} title={t("admin")}>
          <Settings className="h-4 w-4"/> {t("admin")}
        </button>
        <button className="inline-flex items-center gap-2 rounded-xl border border-zinc-200 bg-white px-3 py-2 text-sm shadow-sm hover:bg-pink-50" onClick={()=>setLang(lang==="ja"?"en":"ja")} title="i18n">
          <Globe className="h-4 w-4"/> {lang.toUpperCase()}
        </button>
      </div>
    </div>
  </header> );
}

function Footer(){
  return (<footer className="border-t border-pink-100 py-6 text-center text-xs text-zinc-500"><div className="mx-auto max-w-6xl px-4">© {new Date().getFullYear()} IZAKAYA verse – Phase 1 (UI only)</div></footer>);
}

// ----------------------------------------------------------
// Routes (hash)
// ----------------------------------------------------------
function Routes(){
  const { path } = useRouterContext();
  const p=path||"/";
  if(p.startsWith('/redeem/')) return <RedeemPage/>;
  switch(p){
    case '/': return <HomePage/>;
    case '/play': return <PlayPage/>;
    case '/library': return <LibraryPage/>;
    case '/tickets': return <TicketsPage/>;
    default: return <NotFound/>;
  }
}

// ----------------------------------------------------------
// Pages: Home / Play / Library / Tickets / Redeem / 404
// ----------------------------------------------------------
function HomePage(){
  const { t } = useRouterContext();
  return (
    <div className="space-y-10">
      <section className="rounded-3xl bg-gradient-to-br from-pink-200/60 to-red-100/70 p-8 shadow-md">
        <div className="flex flex-col items-start gap-6 md:flex-row md:items-center md:justify-between">
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight text-red-700 flex items-center gap-3"><Sparkles className="h-6 w-6"/> IZAKAYA verse</h1>
            <p className="mt-2 text-zinc-700">{t('heroTag')}</p>
            <div className="mt-4 h-32 w-full rounded-xl bg-gray-200 flex items-center justify-center text-xs text-gray-500">banner_placeholder.png</div>
          </div>
          <div className="flex items-center gap-3">
            <NavLink to="/play" className="inline-flex items-center gap-2 rounded-2xl bg-red-500 px-5 py-3 text-white shadow-lg transition hover:bg-red-600">
              <Bot className="h-5 w-5"/> {t('ctaTry')} <ChevronRight className="h-4 w-4"/>
            </NavLink>
          </div>
        </div>
      </section>

      <section className="flex items-center justify-between rounded-2xl bg-pink-50 p-4 shadow">
        <span className="text-sm font-medium text-zinc-700">{t('quickAccess')}</span>
        <div className="flex gap-3">
          <NavLink to="/play" className="rounded-xl bg-red-100 px-4 py-2 text-red-700">Play</NavLink>
          <NavLink to="/tickets" className="rounded-xl bg-red-100 px-4 py-2 text-red-700">Tickets</NavLink>
        </div>
      </section>
    </div>
  );
}

const PRESET_CARDS={
  orb:{ key:'orb', name:'Dr. Orb', first_mes:'私はDr. Orb。AI考古学の酒場へようこそ。今日の一杯はアルゴリズム・ハイボールだ。', behavior:'論理→比喩→ユーモアの順に返答。難解さは避ける。リンク提示は2件まで。', links:[{title:'Lab notes',url:'#'},{title:'Field log',url:'#'}]},
  ekubo:{ key:'ekubo', name:'Ekubo', first_mes:'えくぼは恋の落とし穴。さ、軽口交わして肩の力を抜こう。', behavior:'軽妙・短文・間合い重視。時々関西弁。', links:[{title:'Playbook',url:'#'},{title:'Clips',url:'#'}]},
  madi:{ key:'madi', name:'Miss Madi', first_mes:'ミス・マディよ。可愛げは武器。ルールは守るけど、抜け道も知ってるの。', behavior:'礼儀正しく、しかし核心は突く。提案は3つ以内。', links:[{title:'Madi Notes',url:'#'},{title:'Etiquette',url:'#'}]},
};

function PlayPage(){
  const { forcedCardKey,setForcedCardKey, admin, t } = useRouterContext();
  const [activeKey,setActiveKey]=useState(forcedCardKey);
  const [customCard,setCustomCard]=useState(null);
  const [firstMesOverride,setFirstMesOverride]=useState("");
  const [isDragging,setIsDragging]=useState(false);
  const baseCards = PRESET_CARDS;
  const cards = useMemo(()=>{
    if(!customCard) return baseCards;
    return { ...baseCards, custom:{ key:'custom', name: customCard.name||'Custom', first_mes: customCard.first_mes||I18N.ja.fallbackCard, behavior: customCard.behavior||'（カスタムカード）', links: customCard.links||[], __avatarUrl: customCard.__avatarUrl||null } };
  },[customCard]);
  const active = cards[activeKey] || cards.orb;
  const greeting=firstMesOverride||active.first_mes;
  const avatarUrl = active.__avatarUrl || null;
  useEffect(()=>setActiveKey(forcedCardKey),[forcedCardKey]);

  async function handleFiles(files){
    const f=files?.[0]; if(!f) return;
    const data=await parseV2CardFromFile(f);
    if(data?.first_mes){
      const normalized={
        name: data.name||data.character||data.title||'Custom',
        first_mes: String(data.first_mes),
        behavior: data.description||data.system_prompt||data.behavior||'',
        links: Array.isArray(data.links)?data.links:[],
        __avatarUrl: data.__avatarUrl||null
      };
      setCustomCard(normalized); setActiveKey('custom'); setFirstMesOverride(normalized.first_mes);
    } else {
      setCustomCard(data||null); // PNG only => avatar
      setFirstMesOverride(data?.first_mes? String(data.first_mes): I18N.ja.fallbackCard);
    }
  }

  return (
    <div className="grid gap-6 md:grid-cols-3">
      <div className="space-y-4 md:col-span-1">
        <div className="rounded-2xl border border-pink-100 bg-white p-3 shadow-sm">
          <div className="flex items-center gap-3 mb-2">
            {avatarUrl && <img src={avatarUrl} alt="avatar" className="h-10 w-10 rounded-full object-cover"/>}
            <div className="text-sm text-zinc-600">V2 PNG をアップロードするとアイコンがここに表示されます</div>
          </div>
          <div className="flex flex-wrap gap-2">
            {Object.values(cards).map((c)=> (
              <button key={c.key} className={cx("flex-1 rounded-xl px-3 py-2 text-sm transition", activeKey===c.key?"bg-red-100 text-red-700":"bg-pink-50 text-zinc-700 hover:bg-pink-100")} onClick={()=>setActiveKey(c.key)}>{c.name}</button>
            ))}
          </div>
          <div className="mt-3 rounded-xl bg-pink-50 p-3 text-sm text-zinc-700">
            <div className="font-medium">{t('firstMes')}:</div>
            <div className="mt-1 whitespace-pre-wrap">{greeting}</div>
            <div className="mt-2 text-xs text-zinc-500">behavior: {active.behavior}</div>
            <div className="mt-1 flex flex-wrap gap-2 text-xs text-red-700">
              {active.links?.map?.((l,i)=>(<a key={i} href={l.url||'#'} className="underline underline-offset-2" target="_blank" rel="noreferrer">{l.title||l.name||`link ${i+1}`}</a>))}
            </div>
          </div>
        </div>

        <div className={cx("rounded-2xl border bg-white p-4 shadow-sm transition", isDragging?"border-red-300 ring-2 ring-red-200":"border-pink-100")}
             onDragOver={(e)=>{e.preventDefault(); setIsDragging(true);}}
             onDragLeave={()=>setIsDragging(false)}
             onDrop={(e)=>{ e.preventDefault(); setIsDragging(false); handleFiles(e.dataTransfer.files); }}>
          <div className="text-sm font-semibold flex items-center gap-2"><Upload className="h-4 w-4"/> {t('uploadV2')}</div>
          <p className="mt-1 text-xs text-zinc-500">PNG（400x600）/JSON/.sAtd — SillyTavern互換（PNGは現状アバターのみ）</p>
          <label className="mt-3 block cursor-pointer rounded-xl border border-dashed border-zinc-300 p-3 text-center text-xs text-zinc-600 hover:bg-pink-50">
            クリックまたはファイルをここにドラッグ&ドロップ
            <input type="file" accept=".png,.json,.satd,application/json,image/png" className="hidden" onChange={(e)=>handleFiles(e.target.files)} />
          </label>
        </div>

        {admin && (
          <div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
            <div className="font-semibold">{t('forceCard')}</div>
            <div className="mt-2 flex gap-2">
              {Object.values(PRESET_CARDS).map((c)=>(
                <button key={c.key} className={cx("rounded-lg px-3 py-1", c.key===activeKey?"bg-red-200":"bg-white border border-red-200")} onClick={()=>{setForcedCardKey(c.key); setActiveKey(c.key);}}>{c.name}</button>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="md:col-span-2">
        <ChatBox greeting={greeting} persona={active.name} avatarUrl={avatarUrl}/>
        <AdminPanel/>
      </div>
    </div>
  );
}

function ChatBox({ greeting, persona, avatarUrl }){
  const { t, counters,setCounters, ttsOn, lang } = useRouterContext();
  const [msgs,setMsgs]=useState([{role:'assistant',content:greeting}]);
  const [input,setInput]=useState("");
  const listRef=useRef(null);

  useEffect(()=>{ setMsgs([{role:'assistant',content:greeting}]); },[greeting]);
  useEffect(()=>{ listRef.current?.lastElementChild?.scrollIntoView({behavior:'smooth'}); },[msgs.length]);

  async function handleSend(){
    const text=input.trim(); if(!text) return; setInput("");
    setMsgs((m)=>[...m,{role:'user',content:text}]); setCounters((c)=>({...c,sent:c.sent+1}));
    const replyBase=`【${persona}】なるほど。ポイントは3つ：\\n1) ${text}\\n2) 実験的UIなので短文で試してね\\n3) フェーズ2+で本接続に差し替え可能`;
    const localized=autoLocalizeForUI(replyBase, lang);
    await new Promise((r)=>setTimeout(r,220));
    setMsgs((m)=>[...m,{role:'assistant',content:localized}]); setCounters((c)=>({...c,received:c.received+1}));
  }
  async function handleTTS(msg){ if(!ttsOn) return; await ttsProvider.speak(msg.content); setCounters((c)=>({...c,tts:c.tts+1})); }

  return (
    <div className="flex h-[400px] flex-col rounded-2xl border border-pink-100 bg-white shadow-sm">
      <div className="flex items-center justify-between border-b border-pink-100 p-3">
        <div className="flex items-center gap-2 text-sm text-zinc-700"><MessageSquare className="h-4 w-4"/> Light Chat (UI only)</div>
        <div className="text-xs text-zinc-500">TTS: {ttsOn?"ON":"OFF"}</div>
      </div>
      <div ref={listRef} className="flex-1 space-y-3 overflow-auto p-4">
        {msgs.map((m,i)=> (
          <div key={i} className={cx("flex items-start gap-2", m.role==='user'?"justify-end":"")}> 
            {m.role!=='user' && (
              <div className="h-7 w-7 flex items-center justify-center rounded-full bg-pink-100 overflow-hidden shrink-0">
                {avatarUrl ? <img src={avatarUrl} alt="av" className="h-7 w-7 object-cover"/> : <Bot className="h-4 w-4 text-red-600"/>}
              </div>
            )}
            <div className={cx("max-w-[88%] rounded-2xl p-3 text-sm shadow", m.role==='user'?"ml-auto bg-red-500 text-white":"bg-pink-50 text-zinc-800")}> 
              <div className="whitespace-pre-wrap">{m.role==='assistant' ? autoLocalizeForUI(m.content, lang) : m.content}</div>
              <div className="mt-2 flex items-center gap-2 text-xs opacity-70">
                <button className={cx("inline-flex items-center gap-1 rounded-lg border px-2 py-1", ttsOn?"border-red-200 bg-red-50 text-red-700":"border-zinc-200 text-zinc-500")} onClick={()=>handleTTS(m)} disabled={!ttsOn} title="TTS"><Volume2 className="h-3.5 w-3.5"/> TTS</button>
              </div>
            </div>
            {m.role==='user' && (
              <div className="h-7 w-7 flex items-center justify-center rounded-full bg-zinc-200 text-[10px] text-zinc-700 shrink-0">You</div>
            )}
          </div>
        ))}
      </div>
      <div className="border-t border-pink-100 p-3">
        <div className="flex gap-2">
          <input className="flex-1 rounded-xl border border-zinc-200 bg-white px-3 py-2 text-sm" placeholder={t('messagePlaceholder')} value={input} onChange={(e)=>setInput(e.target.value)} onKeyDown={(e)=> e.key==='Enter' && handleSend() }/>
          <button className="rounded-xl bg-red-500 px-4 py-2 text-sm text-white shadow hover:bg-red-600" onClick={handleSend}>{t('send')}</button>
        </div>
      </div>
    </div>
  );
}

function LibraryPage(){
  const { t, admin } = useRouterContext();
  return (
    <div className="space-y-6">
      <p className="text-sm text-zinc-600">{t('libraryIntro')}</p>
      <div className="grid gap-4 md:grid-cols-3">
        {[
          { key: "orb", title: "Dr. Orb", desc: PRESET_CARDS.orb.behavior },
          { key: "ekubo", title: "Ekubo", desc: PRESET_CARDS.ekubo.behavior },
          { key: "madi", title: "Miss Madi", desc: PRESET_CARDS.madi.behavior },
        ].map((it)=>(
          <div key={it.key} className="rounded-2xl border border-pink-100 bg-white p-4 shadow-sm">
            <div className="w-full aspect-[2/3] rounded-xl bg-gray-200 flex items-center justify-center text-xs text-gray-500">card_placeholder.png</div>
            <div className="mt-3 text-sm font-semibold">{it.title}</div>
            <div className="mt-1 text-xs text-zinc-500 line-clamp-3">{it.desc}</div>
            <div className="mt-3 flex gap-2">
              <button className="cursor-not-allowed rounded-lg border border-zinc-200 px-3 py-1 text-xs text-zinc-400" title="disabled">投稿 {t('disabledSoon')}</button>
              <button className="cursor-not-allowed rounded-lg border border-zinc-200 px-3 py-1 text-xs text-zinc-400" title="disabled">交換 {t('disabledSoon')}</button>
            </div>
          </div>
        ))}
      </div>
      {admin && (
        <div className="rounded-2xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
          <div className="font-semibold">{t('adminOnly')}</div>
          <ul className="mt-2 list-inside list-disc space-y-1">
            <li>dr_orb.v2.json</li>
            <li>ekubo_card.png</li>
            <li>miss_madi.sAtd</li>
          </ul>
        </div>
      )}
    </div>
  );
}

function TicketsPage(){
  const { t } = useRouterContext();
  function pdfEscape(input){ let s=String(input); s=s.replaceAll('\\\\','\\\\\\\\').replaceAll('(','\\\\(').replaceAll(')','\\\\)'); return s; }
  function buildTinyPdf(text="IZAKAYA verse Ticket – Draft\\nPhase 1 UI only"){
    const safe=pdfEscape(text);
    const content=`%PDF-1.4\\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\\n2 0 obj<</Type/Pages/Count 1/Kids[3 0 R]>>endobj\\n3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 612 792]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj\\n4 0 obj<</Length 44>>stream\\nBT /F1 24 Tf 72 720 Td (${safe}) Tj ET\\nendstream endobj\\n5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\\nxref\\n0 6\\n0000000000 65535 f \\n0000000010 00000 n \\n0000000060 00000 n \\n0000000117 00000 n \\n0000000283 00000 n \\n0000000417 00000 n \\ntrailer<</Root 1 0 R/Size 6>>\\nstartxref\\n510\\n%%EOF`;
    return new Blob([content],{type:'application/pdf'});
  }
  function downloadPdf(){ const blob=buildTinyPdf("IZAKAYA verse Ticket – Draft"); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download='izakaya_ticket_draft.pdf'; a.click(); URL.revokeObjectURL(url); }
  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-pink-100 bg-white p-5 shadow-sm">
        <div className="flex items-center gap-2 text-lg font-semibold text-red-700"><TicketIcon className="h-5 w-5"/> {t('ticketsTitle')}</div>
        <p className="mt-2 text-sm text-zinc-600">{t('ticketsText')}</p>
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          <div className="rounded-xl border border-zinc-200 p-4"><div className="text-sm font-semibold">{t('price1000')}</div><p className="mt-1 text-xs text-zinc-500">Amazon / pixiv 同時出品予定</p></div>
          <div className="rounded-xl border border-zinc-200 p-4"><div className="text-sm font-semibold">{t('price5000')}</div><p className="mt-1 text-xs text-zinc-500">Amazon / pixiv 同時出品予定</p></div>
        </div>
        <div className="mt-4 rounded-xl bg-pink-50 p-4 text-sm text-zinc-700"><div className="font-medium">{t('dynQR')}</div><p className="mt-1 text-xs text-zinc-600">フェーズ1ではルーティングのみ確保（/redeem/:token）。実装はフェーズ2+で差し替え。</p></div>
        <div className="mt-4"><button onClick={downloadPdf} className="inline-flex items-center gap-2 rounded-xl border border-red-200 bg-red-50 px-4 py-2 text-red-700 hover:bg-red-100"><Download className="h-4 w-4"/> {t('pdfDraft')}</button></div>
      </div>
      <FAQ/>
    </div>
  );
}

function FAQ(){
  const { t } = useRouterContext();
  return (
    <div className="rounded-2xl border border-pink-100 bg-white p-5 shadow-sm">
      <div className="text-sm font-semibold">{t('faqLead')}</div>
      <ul className="mt-2 list-inside list-disc text-sm text-zinc-600">
        <li>現状はUI説明のみ。支払い・照合はダミーAPIに接続。</li>
        <li>ダイナミックQRは将来の /redeem/:token で引換。</li>
        <li>配色は薄ピンク×赤（V1調）。コントラスト最適化済み。</li>
      </ul>
    </div>
  );
}

function RedeemPage(){
  const { path, t } = useRouterContext();
  const token=(path.split('/redeem/')[1]||'').split('/')[0];
  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-pink-100 bg-white p-5 shadow-sm">
        <div className="text-lg font-semibold text-red-700">{t('redeemTitle')}</div>
        <p className="mt-2 text-sm text-zinc-600">{t('tokenIs')}: <code className="rounded bg-pink-100 px-2 py-1">{token}</code></p>
        <p className="mt-2 text-xs text-zinc-500">Phase 2+ で usePoints() と連動予定（ダミーAPI差替）。</p>
      </div>
    </div>
  );
}

function NotFound(){
  const { path } = useRouterContext();
  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-pink-100 bg-white p-6 shadow-sm">
        <div className="text-lg font-semibold text-red-700">404</div>
        <p className="mt-2 text-sm text-zinc-600">Page not found: <code>{path}</code></p>
        <p className="mt-1 text-xs text-zinc-500">Use the top navigation to return.</p>
      </div>
    </div>
  );
}

function AdminPanel(){
  const { admin,setAdmin, pointsApi, counters,setCounters, t, ttsOn,setTtsOn, forcedCardKey,setForcedCardKey } = useRouterContext();
  if(!admin) return null;
  return (
    <div className={"mt-6 rounded-2xl border border-pink-100 bg-white p-5 shadow-sm"}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm font-semibold"><Settings className="h-4 w-4"/> {t('admin')}</div>
        <button className="rounded-lg border border-zinc-200 px-2 py-1 text-xs text-zinc-600 hover:bg-pink-50" onClick={()=>setAdmin(false)}>Close</button>
      </div>
      <div className="mt-3 grid gap-3 md:grid-cols-3">
        <div className="rounded-xl border border-zinc-200 bg-white p-3">
          <div className="text-xs font-semibold text-zinc-700">{t('points')}</div>
          <div className="mt-1 text-2xl font-bold text-red-700">{pointsApi.points} pt</div>
          <div className="mt-2 flex gap-2">
            <button className="rounded-lg border border-zinc-200 px-2 py-1 text-xs" onClick={()=>pointsApi.add(50)}>+50</button>
            <button className="rounded-lg border border-zinc-200 px-2 py-1 text-xs" onClick={()=>pointsApi.spend(50)}>-50</button>
          </div>
          <div className="mt-2 text-[10px] text-zinc-500">※ 試験操作（ダミー）</div>
        </div>
        <div className="rounded-xl border border-zinc-200 bg白 p-3">
          <div className="text-xs font-semibold text-zinc-700">Log</div>
          <div className="mt-2 grid grid-cols-3 gap-2 text-center text-xs">
            <div className="rounded-lg bg-pink-50 p-2"><div className="font-semibold text-red-700">{counters.sent}</div><div className="text-[10px] text-zinc-600">{t('sent')}</div></div>
            <div className="rounded-lg bg-pink-50 p-2"><div className="font-semibold text-red-700">{counters.received}</div><div className="text-[10px] text-zinc-600">{t('received')}</div></div>
            <div className="rounded-lg bg-pink-50 p-2"><div className="font-semibold text-red-700">{counters.tts}</div><div className="text-[10px] text-zinc-600">{t('ttsClicks')}</div></div>
          </div>
          <div className="mt-2 flex justify-center gap-2"><button className="rounded-lg border border-zinc-200 px-2 py-1 text-[10px]" onClick={()=>setCounters({sent:0,received:0,tts:0})}>Reset</button></div>
        </div>
      </div>
    </div>
  );
}

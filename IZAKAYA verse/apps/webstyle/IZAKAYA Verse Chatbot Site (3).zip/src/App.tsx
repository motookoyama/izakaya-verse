import { useState } from 'react';
import { SteampunkCharacterCard } from './components/steampunk-character-card';
import { SteampunkMultiplayerChat } from './components/steampunk-multiplayer-chat';
import { Button } from './components/ui/button';
import { Card, CardContent } from './components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Badge } from './components/ui/badge';
import { Users, Cog, Zap, Trophy, Shield, MessageSquare } from 'lucide-react';
import { ImageWithFallback } from './components/figma/ImageWithFallback';

interface Character {
  id: string;
  name: string;
  type: string;
  rarity: "Common" | "Rare" | "Epic" | "Legendary";
  power: number;
  health: number;
  abilities: string[];
  image: string;
  owned: boolean;
}

interface Player {
  id: string;
  name: string;
  avatar: string;
  character: string;
  isOnline: boolean;
}

const characters: Character[] = [
  {
    id: '1',
    name: 'Copper Dynamo',
    type: 'Steam Engineer',
    rarity: 'Legendary',
    power: 95,
    health: 80,
    abilities: ['Pressure Surge', 'Gear Mastery', 'Steam Boost'],
    image: 'https://images.unsplash.com/photo-1546710237-057a5519a3d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGVhbXB1bmslMjBnZWFycyUyMG1hY2hpbmVyeXxlbnwxfHx8fDE3NTg1NDAyMzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    owned: true
  },
  {
    id: '2',
    name: 'Brass Artificer',
    type: 'Mechanical Inventor',
    rarity: 'Epic',
    power: 88,
    health: 65,
    abilities: ['Bronze Shields', 'Clockwork Precision', 'Automaton Command'],
    image: 'https://images.unsplash.com/photo-1719752486455-3c6809b5e238?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwaW5kdXN0cmlhbCUyMGNvcHBlcnxlbnwxfHx8fDE3NTg1NDAyMzd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    owned: true
  },
  {
    id: '3',
    name: 'Iron Chronometer',
    type: 'Temporal Mechanic',
    rarity: 'Rare',
    power: 70,
    health: 120,
    abilities: ['Time Lock', 'Gear Acceleration', 'Mechanical Repair'],
    image: 'https://images.unsplash.com/photo-1614779622523-9b240f06df96?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWNoYW5pY2FsJTIwY2xvY2t3b3JrJTIwYW50aXF1ZXxlbnwxfHx8fDE3NTg1NDAyNDB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    owned: false
  },
  {
    id: '4',
    name: 'Steam Alchemist',
    type: 'Industrial Scientist',
    rarity: 'Epic',
    power: 82,
    health: 75,
    abilities: ['Chemical Fusion', 'Pressure Control', 'Vapor Analysis'],
    image: 'https://images.unsplash.com/photo-1723988433056-b9f34d1dcb17?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxicm9uemUlMjBicmFzcyUyMG1hY2hpbmVyeSUyMGRhcmt8ZW58MXx8fHwxNzU4NTQwMjQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    owned: true
  }
];

export default function App() {
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(characters.find(c => c.owned) || null);
  const [activeTab, setActiveTab] = useState('collection');
  const [currentPlayer] = useState<Player>({
    id: '1',
    name: 'Player1',
    avatar: '⚙️',
    character: selectedCharacter?.name || 'No Character',
    isOnline: true
  });

  const handleCharacterSelect = (id: string) => {
    const character = characters.find(c => c.id === id);
    if (character && character.owned) {
      setSelectedCharacter(character);
    }
  };

  const handleStartAdventure = () => {
    setActiveTab('adventure');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-stone-900 via-slate-900 to-stone-900 relative">
      {/* Background Image */}
      <div className="absolute inset-0 opacity-20">
        <ImageWithFallback 
          src="https://images.unsplash.com/photo-1546710237-057a5519a3d1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGVhbXB1bmslMjBnZWFycyUyMG1hY2hpbmVyeXxlbnwxfHx8fDE3NTg1NDAyMzN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Steampunk gears machinery"
          className="w-full h-full object-cover sepia-[0.8] contrast-[1.2]"
        />
      </div>

      {/* Industrial grid overlay */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="w-full h-full" style={{
          backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 50px, rgba(251, 191, 36, 0.2) 50px, rgba(251, 191, 36, 0.2) 52px), repeating-linear-gradient(90deg, transparent, transparent 50px, rgba(251, 191, 36, 0.2) 50px, rgba(251, 191, 36, 0.2) 52px)',
        }}></div>
      </div>

      {/* Mechanical corner decorations */}
      <div className="absolute top-4 left-4 w-8 h-8 border-l-4 border-t-4 border-yellow-600/40"></div>
      <div className="absolute top-4 right-4 w-8 h-8 border-r-4 border-t-4 border-yellow-600/40"></div>
      <div className="absolute bottom-4 left-4 w-8 h-8 border-l-4 border-b-4 border-yellow-600/40"></div>
      <div className="absolute bottom-4 right-4 w-8 h-8 border-r-4 border-b-4 border-yellow-600/40"></div>

      {/* Gear animations */}
      <div className="absolute top-8 right-8 opacity-20 pointer-events-none">
        <Cog className="w-16 h-16 text-yellow-600 animate-spin-slow" style={{ animationDuration: '40s' }} />
      </div>
      <div className="absolute bottom-8 left-8 opacity-15 pointer-events-none">
        <Cog className="w-12 h-12 text-orange-600 animate-spin-slow" style={{ animationDuration: '30s', animationDirection: 'reverse' }} />
      </div>

      {/* Header */}
      <div className="relative z-10 p-6">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="w-20 h-20 bg-gradient-to-br from-yellow-600 to-orange-700 rounded-lg flex items-center justify-center border-4 border-yellow-500 shadow-lg relative">
              <Cog className="w-10 h-10 text-yellow-100 animate-spin-slow" style={{ animationDuration: '20s' }} />
              <div className="absolute top-1 left-1 w-2 h-2 bg-yellow-300 rounded-full"></div>
              <div className="absolute bottom-1 right-1 w-2 h-2 bg-yellow-300 rounded-full"></div>
            </div>
            <div className="text-center">
              <h1 className="text-6xl text-transparent bg-gradient-to-r from-yellow-500 via-orange-500 to-yellow-500 bg-clip-text drop-shadow-lg font-mono uppercase tracking-wider">
                IZAKAYA VERSE
              </h1>
              <div className="flex items-center justify-center gap-2 mt-2">
                <div className="w-8 h-0.5 bg-gradient-to-r from-transparent to-yellow-600"></div>
                <Zap className="w-6 h-6 text-yellow-500" />
                <div className="w-8 h-0.5 bg-gradient-to-l from-transparent to-yellow-600"></div>
              </div>
            </div>
            <div className="w-20 h-20 bg-gradient-to-br from-orange-600 to-yellow-700 rounded-lg flex items-center justify-center border-4 border-orange-500 shadow-lg relative">
              <Zap className="w-10 h-10 text-orange-100" />
              <div className="absolute top-1 right-1 w-2 h-2 bg-orange-300 rounded-full"></div>
              <div className="absolute bottom-1 left-1 w-2 h-2 bg-orange-300 rounded-full"></div>
            </div>
          </div>
          <p className="text-yellow-300 text-xl drop-shadow font-mono uppercase tracking-widest">
            ⚙ MECHANICAL CHARACTER COLLECTION & STEAMPUNK ADVENTURE ⚙
          </p>
        </div>

        {/* Stats */}
        <div className="flex justify-center gap-6 mb-8">
          <Card className="bg-stone-800/80 backdrop-blur-sm border-2 border-yellow-600/50 shadow-lg">
            <CardContent className="p-4 text-center">
              <Users className="w-6 h-6 text-yellow-500 mx-auto mb-2" />
              <p className="text-yellow-300 text-sm font-mono uppercase">Engineers</p>
              <p className="text-yellow-400 font-mono">2,847</p>
            </CardContent>
          </Card>
          <Card className="bg-stone-800/80 backdrop-blur-sm border-2 border-orange-600/50 shadow-lg">
            <CardContent className="p-4 text-center">
              <Trophy className="w-6 h-6 text-orange-500 mx-auto mb-2" />
              <p className="text-orange-300 text-sm font-mono uppercase">Expeditions</p>
              <p className="text-orange-400 font-mono">15,632</p>
            </CardContent>
          </Card>
          <Card className="bg-stone-800/80 backdrop-blur-sm border-2 border-stone-500/50 shadow-lg">
            <CardContent className="p-4 text-center">
              <Cog className="w-6 h-6 text-stone-400 mx-auto mb-2" />
              <p className="text-stone-300 text-sm font-mono uppercase">Automatons</p>
              <p className="text-stone-400 font-mono">156</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 px-6 pb-6">
        <div className="max-w-7xl mx-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-stone-800/80 backdrop-blur-sm border-2 border-yellow-600 shadow-lg">
              <TabsTrigger 
                value="collection" 
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-yellow-600 data-[state=active]:to-orange-600 data-[state=active]:text-yellow-100 font-mono uppercase tracking-wider"
              >
                <Cog className="w-4 h-4 mr-2" />
                ⚙ MECHANICAL COLLECTION
              </TabsTrigger>
              <TabsTrigger 
                value="adventure"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-600 data-[state=active]:to-yellow-600 data-[state=active]:text-orange-100 font-mono uppercase tracking-wider"
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                🔧 ENGINEERING BAY
              </TabsTrigger>
            </TabsList>

            <TabsContent value="collection" className="mt-6">
              <div className="grid lg:grid-cols-2 gap-8">
                {/* Character Selection */}
                <div className="space-y-6">
                  <div className="text-center">
                    <h2 className="text-3xl text-yellow-300 mb-2 font-mono uppercase tracking-wide">Your Mechanical Arsenal ⚙</h2>
                    <p className="text-yellow-400 font-mono uppercase tracking-wider">Engineer and upgrade powerful automatons for expeditions</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    {characters.map((character) => (
                      <SteampunkCharacterCard
                        key={character.id}
                        {...character}
                        onSelect={handleCharacterSelect}
                      />
                    ))}
                  </div>
                </div>

                {/* Selected Character & Adventure Start */}
                <div className="space-y-6">
                  {selectedCharacter ? (
                    <div className="space-y-4">
                      <Card className="bg-gradient-to-br from-stone-800/80 to-slate-800/80 border-2 border-yellow-600/50 backdrop-blur-sm shadow-lg">
                        <CardContent className="p-6 text-center">
                          <h3 className="text-xl text-yellow-300 mb-4 font-mono uppercase tracking-wider">Active Automaton ⚙</h3>
                          <div className="space-y-3">
                            <h4 className="text-lg text-yellow-300 font-mono uppercase">{selectedCharacter.name}</h4>
                            <div className="flex justify-center gap-4">
                              <Badge className="bg-orange-900 text-orange-300 border-orange-600 font-mono">
                                <Zap className="w-3 h-3 mr-1" />
                                {selectedCharacter.power}
                              </Badge>
                              <Badge className="bg-blue-900 text-blue-300 border-blue-600 font-mono">
                                <Shield className="w-3 h-3 mr-1" />
                                {selectedCharacter.health}
                              </Badge>
                            </div>
                            <div className="flex flex-wrap gap-1 justify-center">
                              {selectedCharacter.abilities.map((ability, index) => (
                                <Badge 
                                  key={index}
                                  variant="outline" 
                                  className="text-xs bg-gradient-to-r from-stone-900 to-slate-800 text-stone-300 border-stone-600 font-mono"
                                >
                                  {ability}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                      
                      <Button 
                        onClick={handleStartAdventure}
                        className="w-full bg-gradient-to-r from-yellow-700 to-orange-700 hover:from-yellow-600 hover:to-orange-600 text-yellow-100 text-lg py-6 shadow-lg hover:shadow-yellow-900/50 border-2 border-yellow-600 font-mono uppercase tracking-wider"
                      >
                        <Cog className="w-5 h-5 mr-2" />
                        Initialize Engineering Bay ⚙
                      </Button>
                    </div>
                  ) : (
                    <Card className="bg-stone-800/50 border-2 border-stone-600 backdrop-blur-sm">
                      <CardContent className="p-6 text-center">
                        <div className="text-stone-400">
                          <Cog className="w-12 h-12 mx-auto mb-4 opacity-50" />
                          <p className="font-mono uppercase tracking-wider">Select an automaton from your arsenal to begin expedition ⚙</p>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                  
                  <div className="space-y-4 text-center">
                    <h3 className="text-xl text-yellow-300 font-mono uppercase tracking-wider">System Features 🔧</h3>
                    <div className="space-y-2 text-yellow-400">
                      <p className="flex items-center justify-center gap-2 font-mono uppercase">
                        <Users className="w-4 h-4 text-yellow-500" />
                        Industrial expeditions with Mechanical Overseer ⚙️
                      </p>
                      <p className="flex items-center justify-center gap-2 font-mono uppercase">
                        <Cog className="w-4 h-4 text-orange-500" />
                        Collect & upgrade mechanical automatons ⚙
                      </p>
                      <p className="flex items-center justify-center gap-2 font-mono uppercase">
                        <Zap className="w-4 h-4 text-stone-400" />
                        AI-guided steampunk narratives 🔧
                      </p>
                      <p className="flex items-center justify-center gap-2 font-mono uppercase">
                        <Trophy className="w-4 h-4 text-yellow-500" />
                        Engineering competitions & rankings 🏭
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="adventure" className="mt-6">
              <Card className="bg-stone-800/90 backdrop-blur-sm border-2 border-yellow-600 shadow-2xl">
                <div className="h-[700px]">
                  <SteampunkMultiplayerChat 
                    roomId="Foundry-001" 
                    currentPlayer={{
                      ...currentPlayer,
                      character: selectedCharacter?.name || 'No Character'
                    }}
                  />
                </div>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Star, Leaf, Crown, Shield } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface ArtNouveauCharacterCardProps {
  id: string;
  name: string;
  type: string;
  rarity: "Common" | "Rare" | "Epic" | "Legendary";
  power: number;
  health: number;
  abilities: string[];
  image: string;
  owned?: boolean;
  onSelect?: (id: string) => void;
}

export function ArtNouveauCharacterCard({ 
  id, 
  name, 
  type, 
  rarity, 
  power, 
  health, 
  abilities, 
  image, 
  owned = false,
  onSelect 
}: ArtNouveauCharacterCardProps) {
  const rarityColors = {
    Common: "bg-amber-50 text-amber-800 border-amber-400",
    Rare: "bg-emerald-50 text-emerald-800 border-emerald-400",
    Epic: "bg-purple-50 text-purple-800 border-purple-400",
    Legendary: "bg-gradient-to-r from-yellow-100 via-orange-100 to-yellow-100 text-yellow-900 border-yellow-500"
  };

  const cardBorders = {
    Common: "border-amber-300 shadow-amber-200/30",
    Rare: "border-emerald-400 shadow-emerald-200/30",
    Epic: "border-purple-400 shadow-purple-200/30", 
    Legendary: "border-yellow-500 shadow-yellow-300/40"
  };

  const cardGradients = {
    Common: "from-stone-50 via-amber-50 to-stone-50",
    Rare: "from-emerald-50 via-teal-50 to-emerald-50",
    Epic: "from-purple-50 via-violet-50 to-purple-50",
    Legendary: "from-yellow-100 via-orange-50 to-amber-100"
  };

  return (
    <Card className={`w-full max-w-sm bg-gradient-to-br ${cardGradients[rarity]} border-2 ${cardBorders[rarity]} shadow-lg hover:shadow-xl transition-all duration-500 hover:scale-[1.02] ${owned ? 'ring-2 ring-yellow-500' : ''} relative overflow-hidden`}>
      {/* Decorative border pattern */}
      <div className="absolute inset-0 border-2 border-yellow-600/20 rounded-lg m-2 pointer-events-none">
        <div className="absolute top-0 left-0 w-6 h-6 border-l-2 border-t-2 border-yellow-600/30"></div>
        <div className="absolute top-0 right-0 w-6 h-6 border-r-2 border-t-2 border-yellow-600/30"></div>
        <div className="absolute bottom-0 left-0 w-6 h-6 border-l-2 border-b-2 border-yellow-600/30"></div>
        <div className="absolute bottom-0 right-0 w-6 h-6 border-r-2 border-b-2 border-yellow-600/30"></div>
      </div>

      <CardHeader className="pb-3 relative">
        <div className="flex justify-between items-start mb-2">
          <Badge variant="outline" className="bg-stone-100 text-stone-700 border-stone-400 font-serif">
            {type}
          </Badge>
          <Badge variant="outline" className={`${rarityColors[rarity]} font-serif`}>
            ⚜ {rarity}
          </Badge>
        </div>
        
        <div className="relative h-32 mb-3 rounded-lg overflow-hidden bg-gradient-to-br from-stone-200 to-amber-100 border border-yellow-600/30">
          <ImageWithFallback 
            src={image}
            alt={name}
            className="w-full h-full object-cover sepia-[0.3] contrast-[1.1]"
          />
          {owned && (
            <div className="absolute top-2 right-2 bg-yellow-500 text-yellow-900 rounded-full p-1.5 border border-yellow-600">
              <Star className="w-3 h-3 fill-current" />
            </div>
          )}
          {/* Ornamental overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-stone-900/10 via-transparent to-yellow-100/20"></div>
          <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-stone-800/20 to-transparent"></div>
        </div>
        
        <CardTitle className="text-lg text-stone-800 font-serif leading-tight">{name}</CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-3 relative">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-1 text-amber-700">
            <Crown className="w-4 h-4" />
            <span className="text-sm font-serif">{power}</span>
          </div>
          <div className="flex items-center gap-1 text-emerald-600">
            <Shield className="w-4 h-4" />
            <span className="text-sm font-serif">{health}</span>
          </div>
        </div>
        
        <div className="space-y-1">
          <p className="text-xs text-stone-600 font-serif italic">Mystical Arts:</p>
          <div className="flex flex-wrap gap-1">
            {abilities.map((ability, index) => (
              <Badge 
                key={index}
                variant="outline" 
                className="text-xs bg-gradient-to-r from-stone-50 to-amber-50 text-stone-700 border-stone-400 font-serif"
              >
                {ability}
              </Badge>
            ))}
          </div>
        </div>
        
        {onSelect && (
          <Button 
            onClick={() => onSelect(id)}
            className="w-full mt-3 bg-gradient-to-r from-yellow-600 to-amber-600 hover:from-yellow-700 hover:to-amber-700 text-yellow-50 shadow-lg hover:shadow-amber-200/50 border border-yellow-700 font-serif"
            disabled={!owned}
          >
            {owned ? (
              <>
                <Leaf className="w-4 h-4 mr-2" />
                Choose Spirit
              </>
            ) : (
              '⚜ Unavailable'
            )}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
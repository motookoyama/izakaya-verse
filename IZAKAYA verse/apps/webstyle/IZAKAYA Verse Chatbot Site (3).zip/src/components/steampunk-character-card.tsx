import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Star, Cog, Zap, Shield } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface SteampunkCharacterCardProps {
  id: string;
  name: string;
  type: string;
  rarity: "Common" | "Rare" | "Epic" | "Legendary";
  power: number;
  health: number;
  abilities: string[];
  image: string;
  owned?: boolean;
  onSelect?: (id: string) => void;
}

export function SteampunkCharacterCard({ 
  id, 
  name, 
  type, 
  rarity, 
  power, 
  health, 
  abilities, 
  image, 
  owned = false,
  onSelect 
}: SteampunkCharacterCardProps) {
  const rarityColors = {
    Common: "bg-stone-800 text-stone-300 border-stone-600",
    Rare: "bg-blue-950 text-blue-300 border-blue-700",
    Epic: "bg-purple-950 text-purple-300 border-purple-700",
    Legendary: "bg-gradient-to-r from-yellow-900 via-orange-900 to-yellow-900 text-yellow-300 border-yellow-600"
  };

  const cardBorders = {
    Common: "border-stone-600 shadow-stone-900/50",
    Rare: "border-blue-700 shadow-blue-900/50",
    Epic: "border-purple-700 shadow-purple-900/50", 
    Legendary: "border-yellow-600 shadow-yellow-900/50"
  };

  const cardGradients = {
    Common: "from-stone-900 via-stone-800 to-stone-900",
    Rare: "from-blue-950 via-slate-900 to-blue-950",
    Epic: "from-purple-950 via-slate-900 to-purple-950",
    Legendary: "from-yellow-900 via-orange-950 to-amber-900"
  };

  return (
    <Card className={`w-full max-w-sm bg-gradient-to-br ${cardGradients[rarity]} border-2 ${cardBorders[rarity]} shadow-lg hover:shadow-xl transition-all duration-500 hover:scale-[1.02] ${owned ? 'ring-2 ring-yellow-500' : ''} relative overflow-hidden`}>
      {/* Mechanical gear decorations */}
      <div className="absolute top-2 right-2 opacity-20">
        <Cog className="w-8 h-8 text-yellow-600/50 animate-spin-slow" style={{ animationDuration: '20s' }} />
      </div>
      <div className="absolute bottom-2 left-2 opacity-15">
        <Cog className="w-6 h-6 text-orange-600/50 animate-spin-slow" style={{ animationDuration: '15s', animationDirection: 'reverse' }} />
      </div>

      {/* Riveted border effect */}
      <div className="absolute inset-0 rounded-lg pointer-events-none">
        <div className="absolute top-3 left-3 w-2 h-2 bg-yellow-600/60 rounded-full"></div>
        <div className="absolute top-3 right-3 w-2 h-2 bg-yellow-600/60 rounded-full"></div>
        <div className="absolute bottom-3 left-3 w-2 h-2 bg-yellow-600/60 rounded-full"></div>
        <div className="absolute bottom-3 right-3 w-2 h-2 bg-yellow-600/60 rounded-full"></div>
      </div>

      <CardHeader className="pb-3 relative">
        <div className="flex justify-between items-start mb-2">
          <Badge variant="outline" className="bg-stone-900 text-stone-300 border-stone-600 font-mono text-xs">
            {type}
          </Badge>
          <Badge variant="outline" className={`${rarityColors[rarity]} font-mono text-xs`}>
            ⚙ {rarity}
          </Badge>
        </div>
        
        <div className="relative h-32 mb-3 rounded-lg overflow-hidden bg-gradient-to-br from-stone-800 to-slate-900 border border-yellow-600/30">
          <ImageWithFallback 
            src={image}
            alt={name}
            className="w-full h-full object-cover sepia-[0.8] contrast-[1.2] brightness-[0.7]"
          />
          {owned && (
            <div className="absolute top-2 right-2 bg-yellow-600 text-yellow-900 rounded-full p-1.5 border border-yellow-500">
              <Star className="w-3 h-3 fill-current" />
            </div>
          )}
          {/* Steam effect overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-stone-900/60 via-transparent to-yellow-600/10"></div>
          <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-t from-stone-900/80 to-transparent"></div>
        </div>
        
        <CardTitle className="text-lg text-yellow-300 font-mono leading-tight tracking-wide">{name}</CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-3 relative">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-1 text-orange-400">
            <Zap className="w-4 h-4" />
            <span className="text-sm font-mono">{power}</span>
          </div>
          <div className="flex items-center gap-1 text-blue-400">
            <Shield className="w-4 h-4" />
            <span className="text-sm font-mono">{health}</span>
          </div>
        </div>
        
        <div className="space-y-1">
          <p className="text-xs text-stone-400 font-mono uppercase tracking-wider">Mechanical Arts:</p>
          <div className="flex flex-wrap gap-1">
            {abilities.map((ability, index) => (
              <Badge 
                key={index}
                variant="outline" 
                className="text-xs bg-gradient-to-r from-stone-900 to-slate-800 text-stone-300 border-stone-600 font-mono"
              >
                {ability}
              </Badge>
            ))}
          </div>
        </div>
        
        {onSelect && (
          <Button 
            onClick={() => onSelect(id)}
            className="w-full mt-3 bg-gradient-to-r from-yellow-700 to-orange-700 hover:from-yellow-600 hover:to-orange-600 text-yellow-100 shadow-lg hover:shadow-yellow-900/50 border border-yellow-600 font-mono uppercase tracking-wider"
            disabled={!owned}
          >
            {owned ? (
              <>
                <Cog className="w-4 h-4 mr-2" />
                ACTIVATE
              </>
            ) : (
              '⚙ LOCKED'
            )}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
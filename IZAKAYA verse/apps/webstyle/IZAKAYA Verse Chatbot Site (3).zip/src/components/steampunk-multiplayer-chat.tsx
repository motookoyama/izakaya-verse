import { useState, useRef, useEffect } from 'react';
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { ScrollArea } from "./ui/scroll-area";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Send, Users, Cog, Zap } from "lucide-react";

interface Player {
  id: string;
  name: string;
  avatar: string;
  character: string;
  isOnline: boolean;
}

interface ChatMessage {
  id: string;
  text: string;
  senderId: string;
  senderName: string;
  senderType: 'player' | 'ai' | 'system';
  timestamp: string;
  character?: string;
}

interface SteampunkMultiplayerChatProps {
  roomId: string;
  currentPlayer: Player;
}

export function SteampunkMultiplayerChat({ roomId, currentPlayer }: SteampunkMultiplayerChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      text: `⚙ SYSTEM INITIALIZED: Welcome to Engineering Bay ${roomId}. Your Mechanical Overseer is online and ready to guide your expedition through the clockwork realms.`,
      senderId: 'system',
      senderName: 'System Protocol',
      senderType: 'system',
      timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
    },
    {
      id: '2',
      text: 'Greetings, fellow engineers and inventors! 🔧 The boilers are running at optimal pressure, and the great mechanisms of this steam-powered citadel await your commands. Your mission begins in the Copper Foundry, where ancient automatons tend to the eternal flames. What mechanical marvels shall we construct today?',
      senderId: 'ai-overseer',
      senderName: 'Mechanical Overseer',
      senderType: 'ai',
      timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [onlinePlayers] = useState<Player[]>([
    currentPlayer,
    {
      id: '2',
      name: 'CopperGear',
      avatar: '⚙️',
      character: 'Steam Engineer',
      isOnline: true
    },
    {
      id: '3', 
      name: 'IronCog',
      avatar: '🔧',
      character: 'Mechanical Inventor',
      isOnline: true
    }
  ]);
  
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  const aiResponses = [
    "Excellent calibration! ⚙️ The pressure gauges spike as your mechanical prowess activates hidden steam vents throughout the foundry...",
    "The automaton spirits approve of your engineering! 🔧 Brass gears begin turning in perfect synchronization, unlocking secret passages...",
    "Outstanding precision! The master clockwork responds to your technical expertise with a symphony of clicking and whirring...",
    "Your mechanized enhancement resonates through the steam pipes! ⚡ The entire citadel's power grid fluctuates in recognition...",
    "Remarkable innovation! The other engineers watch in admiration as your unique contraption demonstrates unprecedented efficiency...",
    "The industrial complex acknowledges your mastery! 🏭 Steam billows from the great chimneys as reality bends to your mechanical will...",
    "A new blueprint materializes: Construct the Temporal Differential Engine to unlock the secrets of the Chronometer Vault! 🕰️⚙️"
  ];

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: inputValue,
      senderId: currentPlayer.id,
      senderName: currentPlayer.name,
      senderType: 'player',
      character: currentPlayer.character,
      timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate Mechanical Overseer response delay
    setTimeout(() => {
      const randomResponse = aiResponses[Math.floor(Math.random() * aiResponses.length)];
      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: randomResponse,
        senderId: 'ai-overseer',
        senderName: 'Mechanical Overseer',
        senderType: 'ai',
        timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
      };
      
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 2500 + Math.random() * 3000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const MessageComponent = ({ message }: { message: ChatMessage }) => {
    const getMessageStyle = () => {
      switch (message.senderType) {
        case 'system':
          return 'bg-gradient-to-r from-stone-900 to-slate-800 border-stone-600 text-stone-300';
        case 'ai':
          return 'bg-gradient-to-r from-yellow-900 to-orange-900 border-yellow-600 text-yellow-200';
        case 'player':
          return message.senderId === currentPlayer.id 
            ? 'bg-gradient-to-r from-blue-950 to-slate-900 border-blue-700 text-blue-200'
            : 'bg-gradient-to-r from-purple-950 to-slate-900 border-purple-700 text-purple-200';
        default:
          return 'bg-stone-900 border-stone-600 text-stone-300';
      }
    };

    const getAvatar = () => {
      switch (message.senderType) {
        case 'system':
          return '⚡';
        case 'ai':
          return '🤖';
        default:
          return onlinePlayers.find(p => p.id === message.senderId)?.avatar || '⚙️';
      }
    };

    return (
      <div className={`flex gap-3 mb-4 ${message.senderId === currentPlayer.id ? 'justify-end' : 'justify-start'}`}>
        {message.senderId !== currentPlayer.id && (
          <Avatar className="w-8 h-8 border-2 border-yellow-600 bg-stone-900">
            <AvatarFallback className="bg-gradient-to-r from-yellow-900 to-orange-900 text-yellow-300 font-mono">
              {getAvatar()}
            </AvatarFallback>
          </Avatar>
        )}
        
        <div className={`max-w-[80%] ${message.senderId === currentPlayer.id ? 'order-1' : 'order-2'}`}>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-sm text-stone-400 font-mono uppercase tracking-wider">{message.senderName}</span>
            {message.character && (
              <Badge variant="outline" className="text-xs bg-gradient-to-r from-stone-900 to-slate-800 text-stone-300 border-stone-600 font-mono">
                ⚙ {message.character}
              </Badge>
            )}
            <span className="text-xs text-stone-500 font-mono">{message.timestamp}</span>
          </div>
          
          <Card className={`${getMessageStyle()} backdrop-blur-sm shadow-md border-2 relative overflow-hidden`}>
            {/* Mechanical corner rivets */}
            <div className="absolute top-1 left-1 w-1.5 h-1.5 bg-yellow-600/60 rounded-full"></div>
            <div className="absolute top-1 right-1 w-1.5 h-1.5 bg-yellow-600/60 rounded-full"></div>
            <div className="absolute bottom-1 left-1 w-1.5 h-1.5 bg-yellow-600/60 rounded-full"></div>
            <div className="absolute bottom-1 right-1 w-1.5 h-1.5 bg-yellow-600/60 rounded-full"></div>
            <CardContent className="p-3">
              <p className="text-sm font-mono leading-relaxed">{message.text}</p>
            </CardContent>
          </Card>
        </div>
        
        {message.senderId === currentPlayer.id && (
          <Avatar className="w-8 h-8 border-2 border-blue-600 bg-stone-900">
            <AvatarFallback className="bg-gradient-to-r from-blue-950 to-slate-900 text-blue-300 font-mono">
              {currentPlayer.avatar}
            </AvatarFallback>
          </Avatar>
        )}
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-br from-stone-900 via-slate-900 to-stone-900 relative">
      {/* Industrial background pattern */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <div className="w-full h-full" style={{
          backgroundImage: 'repeating-linear-gradient(90deg, transparent, transparent 30px, rgba(251, 191, 36, 0.1) 30px, rgba(251, 191, 36, 0.1) 32px)',
        }}></div>
      </div>
      
      {/* Gear decorations */}
      <div className="absolute top-4 right-4 opacity-15 pointer-events-none">
        <Cog className="w-12 h-12 text-yellow-600 animate-spin-slow" style={{ animationDuration: '30s' }} />
      </div>
      
      {/* Room Header */}
      <div className="p-4 border-b-2 border-yellow-600/30 bg-gradient-to-r from-stone-900 via-slate-900 to-stone-900 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-600/10 to-transparent"></div>
        <div className="flex items-center justify-between relative">
          <div>
            <h3 className="text-lg text-yellow-300 font-mono uppercase tracking-wider">⚙ Engineering Bay {roomId}</h3>
            <p className="text-sm text-orange-400 font-mono">AI-Controlled Industrial Complex</p>
          </div>
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-yellow-500" />
            <span className="text-sm text-yellow-400 font-mono">{onlinePlayers.filter(p => p.isOnline).length} engineers online</span>
          </div>
        </div>
      </div>

      {/* Players List */}
      <div className="p-3 border-b border-yellow-600/20 bg-gradient-to-r from-slate-900 to-stone-900">
        <div className="flex gap-2 overflow-x-auto">
          {onlinePlayers.map((player) => (
            <div key={player.id} className="flex items-center gap-2 bg-stone-900/80 backdrop-blur-sm rounded px-3 py-1 whitespace-nowrap border border-yellow-600/50 shadow-sm">
              <span className="text-sm">{player.avatar}</span>
              <span className="text-xs text-yellow-300 font-mono uppercase">{player.name}</span>
              {player.isOnline && <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>}
            </div>
          ))}
        </div>
      </div>
      
      {/* Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
        <div className="space-y-4">
          {messages.map((message) => (
            <MessageComponent key={message.id} message={message} />
          ))}
          {isTyping && (
            <div className="flex items-center gap-3">
              <Avatar className="w-8 h-8 border-2 border-yellow-600 bg-stone-900">
                <AvatarFallback className="bg-gradient-to-r from-yellow-900 to-orange-900 text-yellow-300 font-mono">
                  <Cog className="w-4 h-4 animate-spin" />
                </AvatarFallback>
              </Avatar>
              <Card className="bg-gradient-to-r from-yellow-900 to-orange-900 border-yellow-600 border-2">
                <CardContent className="p-3">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-yellow-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-yellow-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-yellow-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </ScrollArea>
      
      {/* Input */}
      <div className="p-4 border-t-2 border-yellow-600/30 bg-gradient-to-r from-stone-900 via-slate-900 to-stone-900 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-600/10 to-transparent"></div>
        <div className="flex gap-2 relative">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Transmit your engineering report..."
            className="flex-1 bg-stone-800/80 backdrop-blur-sm border-2 border-yellow-600 text-yellow-200 placeholder-yellow-600/60 focus:border-yellow-500 shadow-sm font-mono"
          />
          <Button 
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || isTyping}
            className="bg-gradient-to-r from-yellow-700 to-orange-700 hover:from-yellow-600 hover:to-orange-600 text-yellow-100 shadow-lg hover:shadow-yellow-900/50 border-2 border-yellow-600 font-mono uppercase"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
import { useState, useRef, useEffect } from 'react';
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { ScrollArea } from "./ui/scroll-area";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Send, Users, Leaf, Crown } from "lucide-react";

interface Player {
  id: string;
  name: string;
  avatar: string;
  character: string;
  isOnline: boolean;
}

interface ChatMessage {
  id: string;
  text: string;
  senderId: string;
  senderName: string;
  senderType: 'player' | 'ai' | 'system';
  timestamp: string;
  character?: string;
}

interface ArtNouveauMultiplayerChatProps {
  roomId: string;
  currentPlayer: Player;
}

export function ArtNouveauMultiplayerChat({ roomId, currentPlayer }: ArtNouveauMultiplayerChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      text: `⚜ Welcome to the Enchanted Salon ${roomId}! Your distinguished AI Curator awaits to guide you through this artistic journey through mystical realms.`,
      senderId: 'system',
      senderName: 'Salon Herald',
      senderType: 'system',
      timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
    },
    {
      id: '2',
      text: 'Esteemed guests, I bid you welcome to this evening\'s soirée! 🍃 The ethereal energies gather around us in this gilded chamber of wonders. Your quest begins in the Botanical Conservatory, where ancient spirits dance among the climbing roses. What artistic endeavor shall we pursue tonight?',
      senderId: 'ai-curator',
      senderName: 'AI Curator',
      senderType: 'ai',
      timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [onlinePlayers] = useState<Player[]>([
    currentPlayer,
    {
      id: '2',
      name: 'VioletMuse',
      avatar: '🌺',
      character: 'Art Nouveau Poetess',
      isOnline: true
    },
    {
      id: '3', 
      name: 'GoldenBrush',
      avatar: '🎨',
      character: 'Master Illustrator',
      isOnline: true
    }
  ]);
  
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  const aiResponses = [
    "Exquisite choice! 🍃 As you move through the conservatory, golden light filters through stained glass, revealing hidden botanical secrets...",
    "The spirits of artisans past whisper their approval! Your aesthetic sensibilities have stirred something magnificent in the ether...",
    "A most distinguished approach! 🌿 The curator's eyes gleam with appreciation as ornamental vines begin to spiral around the gallery walls...",
    "Your character's artistic aura resonates beautifully! ⚜ The very air shimmers with creative potential, and reality bends to your vision...",
    "Remarkable technique! The other patrons observe with cultured admiration as your unique artistic interpretation unfolds...",
    "The mystical salon responds to your refined taste! 🌹 Time seems to flow like honey as Art Nouveau patterns dance through the atmosphere...",
    "A new commission appears: Create an illuminated manuscript depicting the Legend of the Gilded Garden! 📜✨"
  ];

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: inputValue,
      senderId: currentPlayer.id,
      senderName: currentPlayer.name,
      senderType: 'player',
      character: currentPlayer.character,
      timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    // Simulate AI Curator response delay
    setTimeout(() => {
      const randomResponse = aiResponses[Math.floor(Math.random() * aiResponses.length)];
      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: randomResponse,
        senderId: 'ai-curator',
        senderName: 'AI Curator',
        senderType: 'ai',
        timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })
      };
      
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 2000 + Math.random() * 3000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const MessageComponent = ({ message }: { message: ChatMessage }) => {
    const getMessageStyle = () => {
      switch (message.senderType) {
        case 'system':
          return 'bg-gradient-to-r from-stone-100 to-amber-50 border-stone-400 text-stone-800';
        case 'ai':
          return 'bg-gradient-to-r from-yellow-50 to-amber-100 border-yellow-500 text-amber-900';
        case 'player':
          return message.senderId === currentPlayer.id 
            ? 'bg-gradient-to-r from-emerald-50 to-teal-100 border-emerald-400 text-emerald-900'
            : 'bg-gradient-to-r from-purple-50 to-violet-100 border-purple-400 text-purple-900';
        default:
          return 'bg-stone-100 border-stone-400 text-stone-800';
      }
    };

    const getAvatar = () => {
      switch (message.senderType) {
        case 'system':
          return '⚜';
        case 'ai':
          return '👑';
        default:
          return onlinePlayers.find(p => p.id === message.senderId)?.avatar || '🎭';
      }
    };

    return (
      <div className={`flex gap-3 mb-4 ${message.senderId === currentPlayer.id ? 'justify-end' : 'justify-start'}`}>
        {message.senderId !== currentPlayer.id && (
          <Avatar className="w-8 h-8 border-2 border-yellow-600 bg-amber-50">
            <AvatarFallback className="bg-gradient-to-r from-yellow-100 to-amber-100 text-amber-800 font-serif">
              {getAvatar()}
            </AvatarFallback>
          </Avatar>
        )}
        
        <div className={`max-w-[80%] ${message.senderId === currentPlayer.id ? 'order-1' : 'order-2'}`}>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-sm text-stone-600 font-serif">{message.senderName}</span>
            {message.character && (
              <Badge variant="outline" className="text-xs bg-gradient-to-r from-amber-50 to-yellow-50 text-amber-800 border-amber-400 font-serif">
                ⚜ {message.character}
              </Badge>
            )}
            <span className="text-xs text-stone-500 font-serif">{message.timestamp}</span>
          </div>
          
          <Card className={`${getMessageStyle()} backdrop-blur-sm shadow-md border-2 relative overflow-hidden`}>
            {/* Decorative corner elements */}
            <div className="absolute top-0 left-0 w-4 h-4 border-l-2 border-t-2 border-yellow-600/40"></div>
            <div className="absolute bottom-0 right-0 w-4 h-4 border-r-2 border-b-2 border-yellow-600/40"></div>
            <CardContent className="p-3">
              <p className="text-sm font-serif leading-relaxed">{message.text}</p>
            </CardContent>
          </Card>
        </div>
        
        {message.senderId === currentPlayer.id && (
          <Avatar className="w-8 h-8 border-2 border-emerald-500 bg-emerald-50">
            <AvatarFallback className="bg-gradient-to-r from-emerald-100 to-teal-100 text-emerald-800 font-serif">
              {currentPlayer.avatar}
            </AvatarFallback>
          </Avatar>
        )}
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-gradient-to-br from-stone-50 via-amber-50 to-yellow-50 relative">
      {/* Decorative background pattern */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="w-full h-full" style={{
          backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 20px, rgba(133, 77, 14, 0.1) 20px, rgba(133, 77, 14, 0.1) 22px)',
        }}></div>
      </div>
      
      {/* Room Header */}
      <div className="p-4 border-b-2 border-yellow-600/30 bg-gradient-to-r from-amber-100 via-yellow-100 to-amber-100 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-200/20 to-transparent"></div>
        <div className="flex items-center justify-between relative">
          <div>
            <h3 className="text-lg text-amber-900 font-serif">⚜ Enchanted Salon {roomId}</h3>
            <p className="text-sm text-amber-700 font-serif italic">AI-Curated Artistic Soirée</p>
          </div>
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-amber-700" />
            <span className="text-sm text-amber-700 font-serif">{onlinePlayers.filter(p => p.isOnline).length} distinguished guests</span>
          </div>
        </div>
      </div>

      {/* Players List */}
      <div className="p-3 border-b border-yellow-600/20 bg-gradient-to-r from-yellow-50 to-amber-50">
        <div className="flex gap-2 overflow-x-auto">
          {onlinePlayers.map((player) => (
            <div key={player.id} className="flex items-center gap-2 bg-white/60 backdrop-blur-sm rounded-full px-3 py-1 whitespace-nowrap border border-yellow-400/50 shadow-sm">
              <span className="text-sm">{player.avatar}</span>
              <span className="text-xs text-amber-800 font-serif">{player.name}</span>
              {player.isOnline && <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>}
            </div>
          ))}
        </div>
      </div>
      
      {/* Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
        <div className="space-y-4">
          {messages.map((message) => (
            <MessageComponent key={message.id} message={message} />
          ))}
          {isTyping && (
            <div className="flex items-center gap-3">
              <Avatar className="w-8 h-8 border-2 border-yellow-600 bg-amber-50">
                <AvatarFallback className="bg-gradient-to-r from-yellow-100 to-amber-100 text-amber-800 font-serif">
                  <Crown className="w-4 h-4" />
                </AvatarFallback>
              </Avatar>
              <Card className="bg-gradient-to-r from-yellow-50 to-amber-100 border-yellow-500 border-2">
                <CardContent className="p-3">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-amber-600 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-amber-600 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-amber-600 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </ScrollArea>
      
      {/* Input */}
      <div className="p-4 border-t-2 border-yellow-600/30 bg-gradient-to-r from-amber-100 via-yellow-100 to-amber-100 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-yellow-200/20 to-transparent"></div>
        <div className="flex gap-2 relative">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Share your artistic inspiration..."
            className="flex-1 bg-white/80 backdrop-blur-sm border-2 border-yellow-500 text-amber-900 placeholder-amber-600 focus:border-yellow-600 shadow-sm font-serif"
          />
          <Button 
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || isTyping}
            className="bg-gradient-to-r from-yellow-600 to-amber-600 hover:from-yellow-700 hover:to-amber-700 text-yellow-50 shadow-lg hover:shadow-amber-200/50 border-2 border-yellow-700 font-serif"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
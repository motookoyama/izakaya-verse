IZAKAYA Bright Chat Skin — bundle

1) chat_skin_bright.html — 単一ファイルのチャットUI（明るめパレット）。ブラウザで開くだけ。

配色は <style> 内の :root の CSS変数を調整すると全体に波及します。
